@extends('app')

@section('content')

<div class="container-fluid">

    <!-- Page Header -->
    <div class="row">
        <div class="col-md-12">
            <h3 style="margin-top: 0; margin-bottom: 20px;">
                <i class="fa fa-pencil-square-o"></i> Edit Task
                <small>#{{ $task->task_id }}</small>
            </h3>
        </div>
    </div>

    <!-- Main Content Row -->
    <div class="row">
        <div class="col-md-8 col-md-offset-2"> <!-- Centered Form -->

            <!-- Standard Bootstrap Panel -->
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Update Task Information</h3>
                </div>

                <div class="panel-body">

                    {{-- Error Alerts --}}
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('tasks.update', $task->task_id) }}" method="POST" class="form-horizontal">
                        @csrf
                        @method('PUT')

                        {{-- Department --}}
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Department</label>
                            <div class="col-sm-9">
                                <select class="form-control" name="dept_id" required>
                                    <option value="">Select Department</option>
                                    @foreach($departments as $dept)
                                        <option value="{{ $dept->dept_id }}" {{ $task->dept_id == $dept->dept_id ? 'selected' : '' }}>
                                            {{ $dept->dept_name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        {{-- Title --}}
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Task Title <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="t_title" value="{{ old('t_title', $task->t_title) }}" required>
                            </div>
                        </div>

                        {{-- Start Time --}}
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Start Time <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control datetimepicker" name="t_start_time" value="{{ old('t_start_time', $task->t_start_time) }}" required>
                            </div>
                        </div>

                        {{-- End Time --}}
                        <div class="form-group">
                            <label class="col-sm-3 control-label">End Time <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control datetimepicker" name="t_end_time" value="{{ old('t_end_time', $task->t_end_time) }}" required>
                            </div>
                        </div>

                        {{-- Status --}}
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Status <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control" name="status" required>
                                    <option value="0" {{ $task->status == 0 ? 'selected' : '' }}>Incomplete</option>
                                    <option value="1" {{ $task->status == 1 ? 'selected' : '' }}>In Progress</option>
                                    <option value="2" {{ $task->status == 2 ? 'selected' : '' }}>Complete</option>
                                </select>
                            </div>
                        </div>

                        {{-- Description --}}
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Description</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="t_description" rows="3">{{ old('t_description', $task->t_description) }}</textarea>
                            </div>
                        </div>

                        {{-- Buttons --}}
                        <div class="form-group">
                            <div class="col-sm-9 col-sm-offset-3">
                                <button type="submit" class="btn btn-primary">Update Task</button>
                                <a href="{{ route('tasks.index') }}" class="btn btn-default">Cancel</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

@endsection
