<style>
    .main-footer {
        background: #fff;
        padding: 20px;
        color: #869099;
        border-top: 1px solid #e3e6f0;
        margin-top: auto; /* Pushes to bottom of flex container */
        border-radius: 5px;
        font-size: 13px;
    }
    .main-footer strong {
        color: #5a5c69;
    }
</style>

<footer class="main-footer text-center">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <strong>&copy; {{ date('Y') }} Giga Mall Task Managment System</strong>
                <span class="pull-right hidden-xs">
                    <b>Version</b> Laravel 1.0.0
                </span>
            </div>
        </div>
    </div>
</footer>
