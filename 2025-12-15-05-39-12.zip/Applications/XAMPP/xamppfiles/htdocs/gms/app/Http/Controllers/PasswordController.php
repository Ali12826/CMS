<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Session;

class PasswordController extends Controller
{
    public function changeTempPassword(Request $request)
    {
        $request->validate([
            'password' => 'required|min:6',
            're_password' => 'required|same:password',
        ]);

        $user = User::find(Session::get('admin_id'));

        $user->password = $request->password;
        $user->temp_password = '';
        $user->save();

        return redirect('/tasks');
    }

    public function changePassword(Request $request)
    {
        $id = Session::get('admin_id');
        $user = User::find($id);

        if ($user->password !== md5($request->admin_old_password)) {
            return back()->withErrors(['msg' => 'Invalid old password']);
        }

        if ($request->admin_new_password !== $request->admin_cnew_password) {
            return back()->withErrors(['msg' => 'Passwords do not match']);
        }

        $user->password = $request->admin_new_password;
        $user->save();

        return redirect('/manage-admin');
    }
}
