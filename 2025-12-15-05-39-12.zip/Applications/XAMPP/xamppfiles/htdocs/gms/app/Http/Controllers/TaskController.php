<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\Admin;
use App\Models\Department;
use App\Models\TaskType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str; // Added for Str::limit in the sidebar

class TaskController extends Controller
{
    public function __construct()
    {
        // Ensure user is logged in for all actions
        $this->middleware('auth');
    }

    /**
     * Display a listing of tasks with filters and supporting data.
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        $user_role = $user->user_role ?? null;
        $user_dept_id = $user->dept_id ?? null;

        // 1. Support lists for Dropdowns
        $departments = Department::orderBy('dept_name')->get();
        $taskTypes   = TaskType::orderBy('task_name')->get();

        // 2. Employees - for filter dropdowns
        $employeesQuery = Admin::where('user_role', 2);
        if ($user_role != 1) {
            // If non-admin, restrict to same department
            $employeesQuery->where('dept_id', $user_dept_id);
        }
        $employees = $employeesQuery->orderBy('fullname')->get();

        // 3. Build tasks query with eager loads
        $tasksQuery = Task::with(['assignedTo', 'assignedBy', 'department'])
            ->orderBy('task_id', 'desc');

        // --- Apply Filters ---

        // Filter: Department
        if ($request->filled('dept_id') && $request->dept_id !== 'all') {
            $tasksQuery->where('dept_id', (int) $request->dept_id);
        }

        // Filter: Employee (Assigned To)
        if ($request->filled('employee_id') && $request->employee_id !== 'all') {
            $tasksQuery->where('t_user_id', (int) $request->employee_id);
        }

        // Filter: Status
        if ($request->filled('status') && $request->status !== 'all') {
            $tasksQuery->where('status', (int) $request->status);
        }

        // Filter: Search (Q)
        if ($request->filled('q')) {
            $q = trim($request->q);
            $tasksQuery->where(function ($qry) use ($q) {
                $qry->where('t_title', 'like', "%{$q}%")
                    ->orWhere('t_description', 'like', "%{$q}%");
            });
        }

        // --- Role Restriction ---
        // Non-admins only see tasks assigned TO them or assigned BY them
        if ($user_role != 1) {
            $tasksQuery->where(function($query) use ($user) {
                $query->where('t_user_id', $user->user_id)
                      ->orWhere('assigned_by', $user->user_id);
            });
        }

        // Pagination
        $tasks = $tasksQuery->paginate(25)->withQueryString();

        // 4. Employee Status List (Side Panel logic)
        $employeeStatusQuery = Admin::select('tbl_admin.*', 'departments.dept_name')
            ->leftJoin('departments', 'tbl_admin.dept_id', '=', 'departments.dept_id')
            ->where('tbl_admin.user_role', 2);

        if ($user_role != 1) {
            $employeeStatusQuery->where('tbl_admin.dept_id', $user_dept_id);
        }

        $employeeStatus = $employeeStatusQuery->orderBy('fullname')->get();

        // Add current task info to each employee
        foreach ($employeeStatus as $emp) {
            // Assuming constants exist in Task model, otherwise use integers 0 and 1
            $currentTask = Task::where('t_user_id', $emp->user_id)
                ->whereIn('status', [0, 1]) // 0=Incomplete, 1=In Progress
                ->orderBy('task_id', 'desc')
                ->first();

            $emp->current_task_title = $currentTask ? $currentTask->t_title : 'Free';
            $emp->task_status        = $currentTask ? $currentTask->status : -1;
        }

        // 5. User-specific summary stats for non-admins
        $userStats = null;
        // You can enable this for admins too if you want, currently set for non-admins (role != 1)
        if ($user_role != 1) {
            $uid = $user->user_id;
            $userStats = [
                'total_tasks' => Task::where('t_user_id', $uid)->count(),
                'completed'   => Task::where('t_user_id', $uid)->where('status', 2)->count(), // 2 = Completed
                'in_progress' => Task::where('t_user_id', $uid)->where('status', 1)->count(), // 1 = In Progress
                'incomplete'  => Task::where('t_user_id', $uid)->where('status', 0)->count(), // 0 = Incomplete
            ];
        }

        return view('tasks.index', compact(
            'tasks',
            'departments',
            'taskTypes',
            'employees',
            'employeeStatus',
            'userStats',
            'user_role',
            'user_dept_id'
        ));
    }

    /**
     * Show the form for creating a new task.
     */
    public function create()
    {
        $departments = Department::orderBy('dept_name')->get();
        // Get employees (role 2) for assignment dropdown
        $employees = Admin::where('user_role', 2)->orderBy('fullname')->get();

        return view('tasks.create', compact('departments', 'employees'));
    }

    /**
     * Store a newly created task in storage.
     */
    public function store(Request $request)
    {
        // Validate inputs using DB column names
        $request->validate([
            't_title'       => 'required|string|max:255',
            'dept_id'       => 'required|exists:departments,dept_id',
            't_description' => 'nullable|string',
            't_start_time'  => 'required|date',
            't_end_time'    => 'required|date|after_or_equal:t_start_time',
            't_user_id'     => 'required|exists:tbl_admin,user_id',
        ]);

        Task::create([
            't_title'       => $request->t_title,
            'dept_id'       => $request->dept_id,
            't_description' => $request->t_description,
            't_start_time'  => Carbon::parse($request->t_start_time),
            't_end_time'    => Carbon::parse($request->t_end_time),
            't_user_id'     => $request->t_user_id,
            'assigned_by'   => Auth::id(), // Uses the logged in user's ID
            'status'        => 0, // 0 = Incomplete default
        ]);

        return redirect()->route('tasks.index')->with('success', 'Task assigned successfully!');
    }

    /**
     * Display the specified task.
     */
    public function show($id)
    {
        $task = Task::with(['assignedTo', 'assignedBy', 'department'])->findOrFail($id);

        // Security: Non-admins can only view if they are the assignee or assigner
        $user = Auth::user();
        if ($user->user_role != 1) {
            if ($task->t_user_id != $user->user_id && $task->assigned_by != $user->user_id) {
                abort(403, 'Unauthorized to view this task.');
            }
        }

        return view('tasks.show', compact('task'));
    }

    /**
     * Show the form for editing the specified task.
     */
    public function edit($id)
    {
        $task = Task::with(['assignedTo', 'assignedBy', 'department'])->findOrFail($id);

        $user = Auth::user();
        // Authorization: Admin, Assigner, or Assignee can edit
        if ($user->user_role != 1 && $task->assigned_by != $user->user_id && $task->t_user_id != $user->user_id) {
            abort(403, 'Unauthorized to edit this task.');
        }

        $departments = Department::orderBy('dept_name')->get();
        $taskTypes   = TaskType::orderBy('task_name')->get();
        $employees   = Admin::where('user_role', 2)->orderBy('fullname')->get();

        return view('tasks.edit', compact('task', 'departments', 'taskTypes', 'employees'));
    }

    /**
     * Update the specified task in storage.
     */
    public function update(Request $request, $id)
    {
        $task = Task::findOrFail($id);
        $user = Auth::user();

        // 1. Define Rules
        $rules = [
            't_title'       => 'required|string|max:255',
            't_description' => 'nullable|string',
            't_start_time'  => 'required|date',
            't_end_time'    => 'required|date|after_or_equal:t_start_time',
            'status'        => 'required|in:0,1,2',
        ];

        // 2. Conditional Validation
        if ($request->has('dept_id')) {
            $rules['dept_id'] = 'exists:departments,dept_id';
        }
        if ($request->has('t_user_id')) {
            $rules['t_user_id'] = 'exists:tbl_admin,user_id';
        }

        $request->validate($rules);

        // 3. Prepare Update Data
        $data = [
            't_title'       => $request->t_title,
            't_description' => $request->t_description,
            't_start_time'  => Carbon::parse($request->t_start_time),
            't_end_time'    => Carbon::parse($request->t_end_time),
            'status'        => (int) $request->status,
        ];

        // 4. Update Relationship fields only if present and authorized
        if ($request->has('dept_id')) {
            $data['dept_id'] = $request->dept_id;
        }

        // Only Admin or the Original Assigner can re-assign the user
        if (($user->user_role == 1 || $user->user_id == $task->assigned_by) && $request->has('t_user_id')) {
            $data['t_user_id'] = $request->t_user_id;
        }

        $task->update($data);

        return redirect()->route('tasks.index')->with('success', 'Task updated successfully!');
    }

    /**
     * Remove the specified task from storage.
     */
    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $user = Auth::user();

        // Allow only admins or the assigner to delete
        if ($user->user_role != 1 && $task->assigned_by != $user->user_id) {
            abort(403, 'Unauthorized to delete this task.');
        }

        $task->delete();

        return redirect()->route('tasks.index')->with('success', 'Task deleted successfully!');
    }

    /**
     * API: dynamic filter options.
     */
    public function getFilterOptions(Request $request)
    {
        $deptId = $request->input('dept_id', 'all');

        // Employees
        $employeesQuery = Admin::select('user_id', 'fullname', 'dept_id')
            ->where('user_role', 2);

        if ($deptId !== 'all') {
            $employeesQuery->where('dept_id', (int) $deptId);
        }

        $employees = $employeesQuery->orderBy('fullname')->get();

        // Task types
        $taskTypesQuery = TaskType::select('task_name');

        if ($deptId !== 'all') {
            $taskTypesQuery->where('dept_id', (int) $deptId);
        }

        $task_types = $taskTypesQuery->distinct()->orderBy('task_name')->pluck('task_name');

        return response()->json([
            'employees'  => $employees,
            'task_types' => $task_types,
        ]);
    }
}
