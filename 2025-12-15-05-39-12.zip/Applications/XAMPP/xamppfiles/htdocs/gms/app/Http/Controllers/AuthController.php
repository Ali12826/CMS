<?php

namespace App\Http\Controllers;

use App\Models\Admin; // Assuming Admin model is used for all users (Admins & Employees)
use App\Models\Department; // Used for fetching department list during registration
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session; // Use Session facade for clarity instead of helper function

class AuthController extends Controller
{
    // ==================== LOGIN/LOGOUT ====================

    /**
     * Display the login view.
     */
    public function showLogin()
    {
        if (Auth::check()) {
            return redirect()->route('tasks.index');
        }
        return view('auth.login');
    }

    /**
     * Handle user login attempt.
     */
    public function login(Request $request)
    {
        $request->validate([
            'username'       => 'required|string',
            'admin_password' => 'required|string',
        ]);

        $username = $request->username;
        // 🔒 Retained MD5 hashing as explicitly requested for compatibility
        $password = md5($request->admin_password);

        // 💡 Use Eloquent directly. Check if user exists with the given username AND MD5 password.
        $admin = Admin::where('username', $username)
                      ->where('password', $password)
                      ->first();

        if ($admin) {
            Auth::login($admin);

            // 💡 Use Session facade for clear, idiomatic Laravel session storage
            Session::put([
                'admin_id'       => $admin->user_id,
                'name'           => $admin->fullname,
                'security_key'   => 'rewsgf@%^&*nmghjjkh', // This is hardcoded and may be unused/unnecessary
                'user_role'      => $admin->user_role,
                'temp_password'  => $admin->temp_password,
                'user_dept_id'   => $admin->dept_id
            ]);

            // Check if temp password exists (forces password change)
            if (!empty($admin->temp_password)) {
                return redirect()->route('change.password.employee');
            }

            return redirect()->route('tasks.index');
        }

        return back()->withErrors([
            'username' => '❌ Invalid Username or Password',
        ])->withInput();
    }

    /**
     * Log the user out of the application.
     */
    public function logout()
    {
        Auth::logout();

        // 💡 Use the Session facade and flush() for a clean session clear
        Session::flush();

        return redirect()->route('login');
    }

    // ==================== REGISTRATION ====================

    /**
     * Display the registration view.
     */
    public function showRegister()
    {
        if (Auth::check()) {
            return redirect()->route('tasks.index');
        }

        // 💡 Use the imported Model directly
        $departments = Department::orderBy('dept_name')->get();
        return view('auth.register', compact('departments'));
    }

    /**
     * Handle user registration (for employees).
     */
    public function register(Request $request)
    {
        $request->validate([
            'fullname' => 'required|string|max:120',
            'username' => 'required|string|max:100|unique:tbl_admin,username|regex:/^[a-zA-Z0-9_-]{3,20}$/',
            'contact'  => 'required|string|max:20',
            'dept_id'  => 'required|exists:departments,dept_id',
            'password' => 'required|string|min:6|confirmed', // 'confirmed' checks for password_confirmation field
        ]);

        Admin::create([
            'fullname'  => $request->fullname,
            'username'  => $request->username,
            'contact'   => $request->contact,
            'dept_id'   => $request->dept_id,
            // 🔒 Retained MD5 hashing as explicitly requested for compatibility
            'password'  => md5($request->password),
            'user_role' => 2, // Employee role (2)
        ]);

        return redirect()->route('login')
                         ->with('success', 'Registration successful! You can now login.');
    }

    // ==================== PASSWORD RESET (Employee Forced) ====================

    /**
     * Display the forced employee password change view (for temp passwords).
     */
    public function showChangePasswordEmployee()
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }
        // 💡 A check should ideally verify 'temp_password' is set before showing the view

        return view('auth.change-password-employee');
    }

    /**
     * Handle the forced employee password change.
     */
    public function changePasswordEmployee(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $request->validate([
            'password'    => 'required|string|min:6',
            're_password' => 'required|string|same:password',
        ]);

        $user = Auth::user();

        $user->update([
            // 🔒 Retained MD5 hashing as explicitly requested for compatibility
            'password'      => md5($request->password),
            'temp_password' => null // Clears the temp password flag
        ]);

        // 💡 Update session data after successful change
        Session::put('temp_password', null);

        return redirect()->route('tasks.index')
                         ->with('success', 'Password updated successfully!');
    }
}
