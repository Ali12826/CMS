<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Department;
use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }

    // ==================== MANAGE ADMINS ====================

    public function manageAdmin()
    {
        // Fetch all admins with their department names
        $admins = DB::table('tbl_admin')
            ->leftJoin('departments', 'tbl_admin.dept_id', '=', 'departments.dept_id')
            ->where('tbl_admin.user_role', 1)
            ->orderBy('tbl_admin.fullname', 'asc')
            ->select('tbl_admin.*', 'departments.dept_name')
            ->get();

        $currentUser = Auth::user();
        $isITAdmin = ($currentUser->dept_id == 2);

        return view('admin.manage-admin', compact('admins', 'isITAdmin'));
    }

    public function storeAdmin(Request $request)
    {
        $request->validate([
            'em_fullname' => 'required|string|max:120',
            'em_username' => 'required|string|max:100|unique:tbl_admin,username|regex:/^[a-zA-Z0-9_-]{3,20}$/',
            'em_contact'  => 'nullable|string|max:50',
            'dept_id'     => 'required|exists:departments,dept_id',
            'em_password' => 'required|string|min:6',
        ]);

        Admin::create([
            'fullname'      => $request->em_fullname,
            'username'      => $request->em_username,
            'contact'       => $request->em_contact ?? '',
            'dept_id'       => $request->dept_id,
            'password'      => md5($request->em_password),
            'temp_password' => null,
            'user_role'     => 1,
        ]);

        return redirect()->route('admin.manage')
                         ->with('success', 'New Admin created successfully!');
    }

    public function editAdmin($id)
    {
        $user = Auth::user();
        $isITAdmin = ($user->dept_id == 2);

        if ($user->user_id != $id && !$isITAdmin) {
            return redirect()->route('admin.manage')
                           ->with('error', 'You do not have permission to edit this profile.');
        }

        $admin = Admin::findOrFail($id);
        $departments = Department::orderBy('dept_name')->get();

        return view('admin.edit-admin', compact('admin', 'departments'));
    }

    public function updateAdmin(Request $request, $id)
    {
        $user = Auth::user();
        $isITAdmin = ($user->dept_id == 2);

        if ($user->user_id != $id && !$isITAdmin) {
            return redirect()->route('admin.manage')
                           ->with('error', 'Access Denied.');
        }

        $request->validate([
            'em_fullname' => 'required|string|max:120',
            'em_username' => 'required|string|max:100|unique:tbl_admin,username,' . $id . ',user_id',
            'em_contact'  => 'nullable|string|max:50',
            'dept_id'     => 'nullable|exists:departments,dept_id',
        ]);

        $admin = Admin::findOrFail($id);
        $admin->update([
            'fullname' => $request->em_fullname,
            'username' => $request->em_username,
            'contact'  => $request->em_contact ?? '',
            'dept_id'  => $request->dept_id,
        ]);

        return redirect()->route('admin.manage')
                         ->with('success', 'Profile updated successfully!');
    }

    // ==================== PASSWORD MANAGEMENT ====================

    public function resetAnyPassword(Request $request, $id)
    {
        $request->validate([
            'new_password' => 'required|string|min:6',
        ]);

        $currentUser = Auth::user();
        $targetUser  = Admin::findOrFail($id);
        $isITAdmin   = ($currentUser->dept_id == 2);

        if ($targetUser->user_role == 1) {
            if (!$isITAdmin && $currentUser->user_id != $targetUser->user_id) {
                return back()->with('error', 'Only IT Super Admins can reset other Admin passwords.');
            }
        } else {
            if (!$isITAdmin && $currentUser->dept_id != $targetUser->dept_id) {
                return back()->with('error', 'You can only manage employees in your own department.');
            }
        }

        $targetUser->update([
            'password'      => md5($request->new_password),
            'temp_password' => null
        ]);

        return back()->with('success', 'Password updated successfully for ' . $targetUser->fullname);
    }

    public function changePassword($id)
    {
        $user_id = Auth::id();
        if ($user_id != $id) {
            return redirect()->route('admin.manage')->with('error', 'Access denied.');
        }
        $admin = Admin::findOrFail($id);
        return view('admin.change-password', compact('admin'));
    }

    public function updatePassword(Request $request, $id)
    {
        $user_id = Auth::id();
        if ($user_id != $id) {
            return redirect()->route('admin.manage')->with('error', 'Access denied.');
        }

        $request->validate([
            'admin_new_password' => 'required|min:6',
            'admin_cnew_password' => 'required|same:admin_new_password',
        ]);

        $admin = Admin::findOrFail($id);
        $admin->update(['password' => md5($request->admin_new_password)]);

        return redirect()->route('admin.manage')->with('success', 'Your password has been updated.');
    }

    public function updateUserPassword(Request $request, $id)
    {
        $request->validate([
            'employee_password' => 'required|string|min:6',
        ]);

        $targetUser = Admin::findOrFail($id);
        $currentUser = Auth::user();
        $isITAdmin = ($currentUser->dept_id == 2);

        if (!$isITAdmin && $currentUser->dept_id != $targetUser->dept_id) {
            return back()->with('error', 'You do not have permission to reset this password.');
        }

        $targetUser->update([
            'password' => md5($request->employee_password),
            'temp_password' => null
        ]);

        return back()->with('success', 'Password updated successfully for ' . $targetUser->fullname);
    }

    // ==================== MANAGE USERS/EMPLOYEES ====================

    public function manageUsers()
    {
        $user = Auth::user();
        $admin_dept_id = $user->dept_id;
        $isITAdmin = ($admin_dept_id == 2);

        $departments = Department::orderBy('dept_name')->get();

        $employees_query = Admin::with('department')->where('user_role', 2);

        if ($admin_dept_id && !$isITAdmin) {
            $employees_query->where('dept_id', $admin_dept_id);
        }

        $employees = $employees_query->orderBy('fullname')->get();

        return view('admin.manage-users', compact('employees', 'departments', 'admin_dept_id', 'isITAdmin'));
    }

    // *** edit employee ***
    public function editUser($id)
    {
        $currentUser = Auth::user();
        $isITAdmin = ($currentUser->dept_id == 2);

        $employee = Admin::findOrFail($id);

        // Security: Check if admin is allowed to edit this user
        if (!$isITAdmin && $currentUser->dept_id != $employee->dept_id) {
            return redirect()->route('admin.manage.users')
                           ->with('error', 'You do not have permission to edit this employee.');
        }

        $departments = Department::orderBy('dept_name')->get();

        return view('admin.edit-user', compact('employee', 'departments'));
    }

    public function storeUser(Request $request)
    {
        $user = Auth::user();
        $admin_dept_id = $user->dept_id;
        $isITAdmin = ($admin_dept_id == 2);

        $request->validate([
            'em_fullname' => 'required|string|max:120',
            'em_username' => 'required|string|max:100|unique:tbl_admin,username|regex:/^[a-zA-Z0-9_-]{3,20}$/',
            'em_contact'  => 'nullable|string|max:50',
            'dept_id'     => 'required|exists:departments,dept_id',
            'em_password' => 'required|string|min:6',
        ]);

        if ($admin_dept_id && !$isITAdmin && $request->dept_id != $admin_dept_id) {
            return back()->withErrors(['dept_id' => 'You can only add employees to your own department.']);
        }

        Admin::create([
            'fullname'      => $request->em_fullname,
            'username'      => $request->em_username,
            'contact'       => $request->em_contact ?? '',
            'dept_id'       => $request->dept_id,
            'password'      => md5($request->em_password),
            'temp_password' => null,
            'user_role'     => 2,
        ]);

        return redirect()->route('admin.manage.users')
                         ->with('success', 'Employee added successfully!');
    }

    public function updateUser(Request $request, $id)
    {
        $request->validate([
            'em_fullname' => 'required|string|max:120',
            'em_username' => 'required|string|max:100|unique:tbl_admin,username,' . $id . ',user_id',
            'em_contact'  => 'nullable|string|max:50',
            'dept_id'     => 'required|exists:departments,dept_id',
        ]);

        $employee = Admin::findOrFail($id);
        $employee->update([
            'fullname' => $request->em_fullname,
            'username' => $request->em_username,
            'contact'  => $request->em_contact ?? '',
            'dept_id'  => $request->dept_id,
        ]);

        return redirect()->route('admin.manage.users')
                         ->with('success', 'Employee updated successfully!');
    }

    public function deleteUser($id)
    {
        $employee = Admin::findOrFail($id);
        $user = Auth::user();
        $isITAdmin = ($user->dept_id == 2);

        if ($user->dept_id && !$isITAdmin && $employee->dept_id != $user->dept_id) {
             return redirect()->route('admin.manage.users')->with('error', 'Access denied.');
        }

        Task::where('t_user_id', $id)->delete();
        $employee->delete();

        return redirect()->route('admin.manage.users')
                         ->with('success', 'Employee deleted successfully!');
    }
}
