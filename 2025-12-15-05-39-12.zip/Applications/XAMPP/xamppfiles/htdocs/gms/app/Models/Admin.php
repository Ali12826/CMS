<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Admin extends Authenticatable
{
    protected $table = 'tbl_admin';

    protected $primaryKey = 'user_id';

    public $timestamps = false;

    protected $fillable = [
        'fullname',
        'username',
        'contact',
        'password',
        'temp_password',
        'user_role',
        'dept_id'
    ];

    protected $hidden = ['password', 'temp_password'];

    /**
     * Relationship: An Admin/User belongs to a Department.
     */
    public function department()
    {
        // belongsTo(RelatedModel, foreign_key, owner_key)
        return $this->belongsTo(Department::class, 'dept_id', 'dept_id');
    }
}
