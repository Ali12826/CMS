<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AdminController; // Added this import

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// 1. LANDING PAGE (public)
Route::get('/', function () {
    return view('landing');
})->name('landing');

// 2. AUTHENTICATION
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// 3. FIRST-TIME PASSWORD CHANGE (auth required)
Route::middleware(['auth'])->group(function () {
    Route::get('/change-password-employee', [AuthController::class, 'showChangePasswordEmployee'])
        ->name('change.password.employee');
    Route::post('/change-password-employee', [AuthController::class, 'changePasswordEmployee'])
        ->name('change.password.employee.post');
});

// 4. PROTECTED APP ROUTES (auth required)
Route::middleware(['auth'])->group(function () {

    // API
    Route::get('tasks/filter/options', [TaskController::class, 'getFilterOptions'])
         ->name('tasks.filter.options');

    // TASKS RESOURCE
    Route::resource('tasks', TaskController::class)->names([
        'index'   => 'tasks.index',
        'show'    => 'tasks.show',
        'create'  => 'tasks.create',
        'store'   => 'tasks.store',
        'edit'    => 'tasks.edit',
        'update'  => 'tasks.update',
        'destroy' => 'tasks.destroy',
    ]);

    // ----------------------------------------------------------------
    // REPORTS
    // ----------------------------------------------------------------
    Route::match(['get', 'post'], '/admin/reports', [ReportController::class, 'index'])
        ->name('admin.reports.index');

    // ==================== ADMIN-ONLY ROUTES ====================
    Route::middleware(['admin'])->prefix('admin')->name('admin.')->group(function () {

        // MANAGE ADMINS
        Route::get('/manage-admin', [AdminController::class, 'manageAdmin'])->name('manage');
        Route::post('/store-admin', [AdminController::class, 'storeAdmin'])->name('store.admin');

        // EDIT / UPDATE ADMIN
        Route::get('/edit-admin/{id}', [AdminController::class, 'editAdmin'])->name('edit');
        Route::put('/update-admin/{id}', [AdminController::class, 'updateAdmin'])->name('update');

        // CHANGE SELF PASSWORD
        Route::get('/change-password/{id}', [AdminController::class, 'changePassword'])->name('change_password');
        Route::post('/update-password/{id}', [AdminController::class, 'updatePassword'])->name('update_password');

        // MANAGE USERS / EMPLOYEES
        Route::get('/manage-users', [AdminController::class, 'manageUsers'])->name('manage.users');
        Route::post('/store-user', [AdminController::class, 'storeUser'])->name('store.user');

        // *** THIS IS THE ROUTE FOR THE EDIT PAGE ***
        Route::get('/edit-user/{id}', [AdminController::class, 'editUser'])->name('edit.user');

        Route::put('/update-user/{id}', [AdminController::class, 'updateUser'])->name('update.user');
        Route::get('/delete-user/{id}', [AdminController::class, 'deleteUser'])->name('delete.user');

        // PASSWORD RESET ROUTES
        Route::post('/update-user-pwd/{id}', [AdminController::class, 'updateUserPassword'])->name('update.user.pwd');
        Route::post('/reset-any-password/{id}', [AdminController::class, 'resetAnyPassword'])->name('reset.any.password');
    });
});
