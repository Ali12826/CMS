<style>
    /* * ==========================================
     * SIDEBAR SPECIFIC STYLING
     * ==========================================
     */
    .sidebar-wrapper {
        background: linear-gradient(180deg, #0A2342 0%, #051324 100%); /* Deep Navy Gradient */
        height: 100%;
        min-height: 100vh;
        color: #ecf0f1;
        box-shadow: 2px 0 15px rgba(0,0,0,0.2);
        display: flex;
        flex-direction: column;
        font-family: 'Inter', sans-serif;
    }

    /* Branding Section */
    .sidebar-brand {
        padding: 25px 15px;
        text-align: center;
        background: rgba(0,0,0,0.2);
        border-bottom: 1px solid rgba(200, 169, 81, 0.1);
    }
    .brand-text {
        color: #fff;
        font-weight: 800;
        font-size: 24px;
        letter-spacing: 1px;
        margin-top: 10px;
        display: block;
    }
    .brand-sub {
        color: #C8A951; /* Gold */
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 2px;
    }

    /* User Profile Section */
    .sidebar-user {
        padding: 20px;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        display: flex;
        align-items: center;
        gap: 12px;
        background: rgba(255,255,255,0.02);
    }
    .user-avatar {
        width: 40px;
        height: 40px;
        background: #C8A951;
        color: #0A2342;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 18px;
        box-shadow: 0 0 10px rgba(200, 169, 81, 0.3);
    }
    .user-info span {
        display: block;
        font-size: 14px;
        font-weight: 600;
        color: #fff;
    }
    .user-info small {
        color: #94a3b8;
        font-size: 11px;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    /* Navigation Links */
    .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 20px 0;
        flex-grow: 1;
    }
    .sidebar-menu li {
        margin-bottom: 5px;
    }
    .sidebar-link {
        display: flex;
        align-items: center;
        padding: 12px 25px;
        color: #bdc3c7;
        text-decoration: none;
        transition: all 0.3s ease;
        border-left: 4px solid transparent;
        font-size: 14px;
    }
    .sidebar-link i {
        width: 25px;
        font-size: 16px;
        margin-right: 10px;
        text-align: center;
        transition: transform 0.2s;
    }

    /* Hover & Active States */
    .sidebar-link:hover {
        background: rgba(255,255,255,0.05);
        color: #fff;
        text-decoration: none;
    }
    .sidebar-link:hover i {
        transform: translateX(3px);
        color: #C8A951;
    }
    .sidebar-menu li.active .sidebar-link {
        background: linear-gradient(90deg, rgba(200, 169, 81, 0.15) 0%, transparent 100%);
        border-left-color: #C8A951;
        color: #fff;
        font-weight: 600;
    }
    .sidebar-menu li.active .sidebar-link i {
        color: #C8A951;
    }

    /* Logout Button Area */
    .sidebar-footer {
        padding: 20px;
        border-top: 1px solid rgba(255,255,255,0.05);
    }
    .btn-logout {
        background: rgba(231, 76, 60, 0.1);
        color: #ff6b6b;
        border: 1px solid rgba(231, 76, 60, 0.3);
        width: 100%;
        padding: 10px;
        border-radius: 6px;
        transition: all 0.3s;
        text-align: center;
        display: block;
        font-weight: 600;
    }
    .btn-logout:hover {
        background: #e74c3c;
        color: white;
        border-color: #e74c3c;
        text-decoration: none;
    }
</style>

<div class="main-sidebar sidebar-wrapper">

    <div class="sidebar-brand">
        <img src="<?php echo e(asset('storage/images/logo12.png')); ?>" alt="GMS Logo" style="height: 60px; width: auto; object-fit: contain;">

        <span class="brand-text">GMS</span>
        <span class="brand-sub">Giga Mall Systems</span>
    </div>

    <div class="sidebar-user">
        <div class="user-avatar">
            
            <?php echo e(substr(Auth::user()->fullname ?? 'U', 0, 1)); ?>

        </div>
        <div class="user-info">
            <span><?php echo e(Auth::user()->fullname ?? 'Guest User'); ?></span>
            <small>
                <?php if(auth()->check() && auth()->user()->user_role == 1): ?>
                    <i class="fa fa-shield" title="Admin"></i> Administrator
                <?php elseif(auth()->check() && auth()->user()->user_role == 2): ?>
                    <i class="fa fa-user-tag" title="Employee"></i> Employee
                <?php else: ?>
                    <i class="fa fa-user" title="Guest"></i> Guest
                <?php endif; ?>
            </small>
        </div>
    </div>

    <ul class="sidebar-menu">

        
        <li class="<?php echo e(Request::is('tasks*') || Request::is('/') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('tasks.index')); ?>" class="sidebar-link">
                <i class="fa fa-tasks"></i>
                <span>Tasks Board</span>
            </a>
        </li>

        
        <?php if(auth()->check() && auth()->user()->user_role == 1): ?>
            <li class="<?php echo e(Request::is('admin/manage-admin*') || Request::is('admin/manage-users*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.manage')); ?>" class="sidebar-link">
                    <i class="fa fa-cogs"></i>
                    <span>Manage Admin</span>
                </a>
            </li>
        <?php endif; ?>

        
        <?php if(auth()->check() && (auth()->user()->user_role == 1 || auth()->user()->user_role == 2)): ?>
            <li class="<?php echo e(Request::is('admin/reports*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin.reports.index')); ?>" class="sidebar-link">
                    <i class="fa fa-bar-chart"></i>
                    <span>System Reports</span>
                </a>
            </li>
        <?php endif; ?>

        
        <?php if(auth()->check() && auth()->user()->user_role == 2): ?>
            <li class="<?php echo e(Request::is('profile*') ? 'active' : ''); ?>">
                <a href="#" class="sidebar-link">
                    <i class="fa fa-id-card"></i>
                    <span>My Profile</span>
                </a>
            </li>
        <?php endif; ?>

    </ul>

    <div class="sidebar-footer">
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-logout">
                <i class="fa fa-sign-out"></i> Logout
            </button>
        </form>
    </div>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>