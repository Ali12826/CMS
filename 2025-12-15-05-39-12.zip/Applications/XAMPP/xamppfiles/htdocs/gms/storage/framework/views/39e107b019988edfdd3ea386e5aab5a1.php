<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="row">
        <div class="col-md-12">
            <h3 style="margin-top: 0; margin-bottom: 20px;">
                <i class="fa fa-eye"></i> Task Details
            </h3>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-8">
                            <h3 class="panel-title" style="line-height: 2;">
                                #<?php echo e($task->task_id); ?> - <?php echo e($task->t_title); ?>

                            </h3>
                        </div>
                        <div class="col-xs-4 text-right">
                            <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-default btn-xs">
                                <i class="fa fa-arrow-left"></i> Back
                            </a>
                            <a href="<?php echo e(route('tasks.edit', $task->task_id)); ?>" class="btn btn-primary btn-xs">
                                <i class="fa fa-pencil"></i> Edit
                            </a>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    
                    <?php
                        $statusLabel = 'label-danger';
                        $statusText = 'Incomplete';
                        if($task->status == 1) { $statusLabel = 'label-warning'; $statusText = 'In Progress'; }
                        elseif($task->status == 2) { $statusLabel = 'label-success'; $statusText = 'Completed'; }
                    ?>

                    <div class="form-horizontal">

                        
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label class="col-sm-3 text-right text-muted">Status:</label>
                            <div class="col-sm-9">
                                <span class="label <?php echo e($statusLabel); ?>" style="font-size: 12px;"><?php echo e($statusText); ?></span>
                            </div>
                        </div>

                        
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label class="col-sm-3 text-right text-muted">Department:</label>
                            <div class="col-sm-9">
                                <strong><?php echo e($task->department->dept_name ?? 'N/A'); ?></strong>
                            </div>
                        </div>

                        
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label class="col-sm-3 text-right text-muted">Assigned To:</label>
                            <div class="col-sm-9">
                                <i class="fa fa-user"></i> <?php echo e($task->assignedTo->fullname ?? 'N/A'); ?>

                            </div>
                        </div>

                        
                        <div class="form-group" style="margin-bottom: 5px;">
                            <label class="col-sm-3 text-right text-muted">Assigned By:</label>
                            <div class="col-sm-9">
                                <i class="fa fa-user-secret"></i> <?php echo e($task->assignedBy->fullname ?? 'N/A'); ?>

                            </div>
                        </div>

                        <hr>

                        
                        <div class="form-group">
                            <label class="col-sm-3 text-right text-muted">Description:</label>
                            <div class="col-sm-9">
                                <p class="lead" style="font-size: 14px;"><?php echo e($task->t_description ?? 'No description provided.'); ?></p>
                            </div>
                        </div>

                        <hr>

                        
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="alert alert-info" style="margin-bottom: 0;">
                                    <strong>Start Time:</strong><br>
                                    <?php echo e(\Carbon\Carbon::parse($task->t_start_time)->format('M d, Y - h:i A')); ?>

                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="alert alert-warning" style="margin-bottom: 0;">
                                    <strong>Due Date:</strong><br>
                                    <?php echo e(\Carbon\Carbon::parse($task->t_end_time)->format('M d, Y - h:i A')); ?>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="panel-footer text-right">
                     <small class="text-muted">
                        Task Created by <strong><?php echo e($task->assignedBy->fullname ?? 'Unknown'); ?></strong>
                        <?php echo e($task->created_at ? ' • ' . $task->created_at->diffForHumans() : ''); ?>

                     </small>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/tasks/show.blade.php ENDPATH**/ ?>