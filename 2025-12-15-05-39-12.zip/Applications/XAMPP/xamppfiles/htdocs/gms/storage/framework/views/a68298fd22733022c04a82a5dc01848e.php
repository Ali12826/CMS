<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

    <style>
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        :root { --giga-blue:#003366; --giga-gold:#b38800; --giga-gold-light:#e0b81c; --export-gold-dark:#8c6a00; --export-gold-light:#ffd700; }
        h1,h2,h3,h4,h5,h6,.panel-heading{font-weight:700;}
        .well-custom{background:#fff;border:none;padding:30px 20px;border-radius:8px;box-shadow:0 10px 25px rgba(0,0,0,.1),0 3px 5px rgba(0,0,0,.05);}
        .report-header{border-bottom:3px solid var(--giga-gold);margin-bottom:20px;}
        .report-header h4{color:var(--giga-blue);}
        .panel-primary,.panel-info{border:1px solid #e7e7e7;}
        .panel-info>.panel-heading,.panel-primary>.panel-heading{color:#fff!important;background:linear-gradient(180deg,#004488 0%, var(--giga-blue) 100%)!important;border-color:var(--giga-blue)!important;border-radius:5px 5px 0 0;}
        .btn-primary{background-color:var(--giga-blue)!important;border-color:var(--giga-blue)!important;box-shadow:0 2px 5px rgba(0,51,102,.4);}
        .btn-primary:hover{background-color:#002244!important;}
        .action-btn.section.csv{background-color:var(--export-gold-light);color:var(--giga-blue);border:1px solid var(--export-gold-dark);font-weight:700;text-shadow:0 1px 0 rgba(255,255,255,.5);box-shadow:0 2px 5px rgba(0,0,0,.3);padding:7px 12px;margin-left:10px;border-radius:4px;display:inline-block;cursor:pointer;}
        .action-btn.section.csv:hover{background-color:var(--giga-gold);color:#fff;text-decoration:none;}
        .compact-task-card{animation:fadeInUp .5s ease-out forwards;opacity:0;}
        .compact-task-card .panel-primary{border:none;border-radius:8px;overflow:hidden;box-shadow:0 8px 15px rgba(0,0,0,.15),0 0 0 1px rgba(179,136,0,.7);transition:transform .3s ease;}
        .compact-task-card .panel-primary:hover{transform:translateY(-3px);}
        .compact-task-card .panel-heading{border-bottom:2px solid var(--giga-gold);min-height:70px;}
        .compact-task-card .huge{font-size:30px;line-height:1;color:var(--giga-gold-light);}
        .dept-stat-info{display:flex;justify-content:space-between;align-items:center;font-size:12px;margin-bottom:5px;border-bottom:1px solid #eee;padding-bottom:2px;}
        .dept-stat-info strong{color:var(--giga-blue);}
        .summary-card{opacity:0;animation:fadeInUp .5s ease-out forwards;}
        .summary-card .panel{box-shadow:0 5px 10px rgba(0,0,0,.1);border-radius:6px;}
        .task-report-table th{background-color:var(--giga-blue);color:#fff;border-color:#002244!important;}
        .task-report-table tr:hover{background-color:#e6e6fa;}
        .report-group .panel-heading{cursor:pointer;display:flex;justify-content:space-between;align-items:center;}
    </style>

    <div class="row">
        <div class="col-md-12">
            <div class="well-custom">
                <h3 class="text-center">
                    <i class="fa fa-bar-chart"></i>
                    <?php echo e((isset($isAdmin) && $isAdmin) ? 'Employee' : 'My'); ?> Performance Report
                </h3>
                <p class="text-center text-muted">
                    <i class="fa fa-clock-o"></i> <?php echo e(now()->format('l, M d, Y h:i:s A')); ?>

                </p>
                <hr>

                
                <div class="panel panel-default">
                    <div class="panel-heading" style="background-color:#f5f5f5; color:#333; overflow:hidden;">
                        <span class="pull-left" style="font-weight:bold; margin-top:5px;">
                            <?php echo e((isset($isAdmin) && $isAdmin) ? 'Department Overview' : 'My Department Stats'); ?>

                        </span>

                        <form action="<?php echo e(route('admin.reports.index')); ?>" method="GET" class="pull-right form-inline" style="margin:0;">
                            <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key != 'dept_stat_filter'): ?>
                                    <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <label><small>Period:</small></label>
                            <select name="dept_stat_filter" class="form-control input-sm" onchange="this.form.submit()">
                                <option value="today" <?php echo e($filters['dept_stat_filter']=='today' ? 'selected' : ''); ?>>Today</option>
                                <option value="yesterday" <?php echo e($filters['dept_stat_filter']=='yesterday' ? 'selected' : ''); ?>>Yesterday</option>
                                <option value="this_week" <?php echo e($filters['dept_stat_filter']=='this_week' ? 'selected' : ''); ?>>This Week</option>
                                <option value="this_month" <?php echo e($filters['dept_stat_filter']=='this_month' ? 'selected' : ''); ?>>This Month</option>
                                <option value="all_time" <?php echo e($filters['dept_stat_filter']=='all_time' ? 'selected' : ''); ?>>All Time</option>
                            </select>
                        </form>
                    </div>

                    <div class="panel-body" style="background:#f9f9f9;">
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $deptStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deptName => $stats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-lg-3 col-md-6 col-sm-6 compact-task-card" style="margin-bottom: 20px;">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            <div class="row">
                                                <div class="col-xs-3">
                                                    <i class="fa fa-building fa-3x" style="opacity:0.5;"></i>
                                                </div>
                                                <div class="col-xs-9 text-right">
                                                    <div class="huge"><?php echo e($stats['Total']); ?></div>
                                                    <div><?php echo e($deptName); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-footer">
                                            <div class="dept-stat-info">
                                                <span>Completed</span>
                                                <strong><?php echo e($stats['Completed']); ?></strong>
                                            </div>
                                            <div class="dept-stat-info">
                                                <span>In Progress</span>
                                                <strong><?php echo e($stats['In Progress']); ?></strong>
                                            </div>
                                            <div class="dept-stat-info">
                                                <span>Incomplete</span>
                                                <strong><?php echo e($stats['Incomplete']); ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-md-12 text-center text-muted">No data found for this period.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <hr style="border-top: 2px dashed #ccc;">

                
                <div class="panel panel-info">
                    <div class="panel-heading"><i class="fa fa-filter"></i> Generate Detailed Report</div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('admin.reports.index')); ?>" method="GET" autocomplete="off">
                            <input type="hidden" name="dept_stat_filter" value="<?php echo e($filters['dept_stat_filter']); ?>">

                            <div class="row">
                                <div class="col-md-3">
                                    <label>Report Type</label>
                                    <select name="report_type" class="form-control" onchange="toggleDateInputs(this.value)">
                                        <option value="weekly"   <?php echo e($filters['report_type']=='weekly' ? 'selected' : ''); ?>>Weekly (7 Days)</option>
                                        <option value="biweekly" <?php echo e($filters['report_type']=='biweekly' ? 'selected' : ''); ?>>Bi-Weekly (14 Days)</option>
                                        <option value="monthly"  <?php echo e($filters['report_type']=='monthly' ? 'selected' : ''); ?>>Monthly</option>
                                        <option value="all_time" <?php echo e($filters['report_type']=='all_time' ? 'selected' : ''); ?>>All Time</option>
                                        <option value="custom"   <?php echo e($filters['report_type']=='custom' ? 'selected' : ''); ?>>Custom Range</option>
                                    </select>
                                </div>
                                <div class="col-md-3" id="start-date-div">
                                    <label>Start Date</label>
                                    <input type="date" name="start_date" class="form-control" value="<?php echo e($filters['start_date']); ?>">
                                </div>
                                <div class="col-md-3" id="end-date-div" style="display: <?php echo e($filters['report_type']=='custom' ? 'block' : 'none'); ?>;">
                                    <label>End Date</label>
                                    <input type="date" name="end_date" class="form-control" value="<?php echo e($filters['end_date']); ?>">
                                </div>
                                <div class="col-md-3">
                                    <label>Grouping</label>
                                    <select name="grouping" class="form-control">
                                        <option value="employee" <?php echo e($filters['grouping']=='employee' ? 'selected' : ''); ?>>By Employee</option>
                                        <option value="task_type" <?php echo e($filters['grouping']=='task_type' ? 'selected' : ''); ?>>By Task Title</option>
                                        <option value="day" <?php echo e($filters['grouping']=='day' ? 'selected' : ''); ?>>By Day</option>
                                        <option value="none" <?php echo e($filters['grouping']=='none' ? 'selected' : ''); ?>>No Grouping</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row" style="margin-top: 15px;">
                                <?php if(isset($isAdmin) && $isAdmin): ?>
                                    <div class="col-md-3">
                                        <label>Department</label>
                                        <select name="dept_id" class="form-control">
                                            <option value="all">All Departments</option>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dept->dept_id); ?>" <?php echo e($filters['dept_id']==$dept->dept_id ? 'selected' : ''); ?>>
                                                    <?php echo e($dept->dept_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Employee</label>
                                        <select name="employee_id" class="form-control">
                                            <option value="all">All Employees</option>
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($emp->user_id); ?>" <?php echo e($filters['employee_id']==$emp->user_id ? 'selected' : ''); ?>>
                                                    <?php echo e($emp->fullname); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <?php else: ?>
                                    
                                    <div class="col-md-3">
                                        <label>Department</label>
                                        <input type="text" class="form-control" value="My Department" disabled style="background-color:#eee;">
                                        <input type="hidden" name="dept_id" value="<?php echo e(auth()->user()->dept_id); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <label>Employee</label>
                                        <input type="text" class="form-control" value="<?php echo e(auth()->user()->fullname); ?>" disabled style="background-color:#eee;">
                                        <input type="hidden" name="employee_id" value="<?php echo e(auth()->id()); ?>">
                                    </div>
                                <?php endif; ?>

                                <div class="col-md-3">
                                    <label>Status</label>
                                    <select name="status_filter" class="form-control">
                                        <option value="all">All Statuses</option>
                                        <option value="2" <?php echo e($filters['status_filter']=='2' ? 'selected' : ''); ?>>Completed</option>
                                        <option value="1" <?php echo e($filters['status_filter']=='1' ? 'selected' : ''); ?>>In Progress</option>
                                        <option value="0" <?php echo e($filters['status_filter']=='0' ? 'selected' : ''); ?>>Incomplete</option>
                                    </select>
                                </div>

                                <div class="col-md-3" style="margin-top: 25px;">
                                    <button type="submit" class="btn btn-primary btn-block">
                                        <i class="fa fa-refresh"></i> Generate Report
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                
                <?php if(isset($reportData)): ?>
                    <div class="report-header">
                        <h4>Results: <?php echo e($filters['start_date']); ?> to <?php echo e($filters['end_date']); ?></h4>
                    </div>

                    <div class="row">
                        <div class="col-md-3 col-sm-6 summary-card">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3"><i class="fa fa-tasks fa-4x"></i></div>
                                        <div class="col-xs-9 text-right">
                                            <h3><?php echo e($reportData['summary']['total']); ?></h3>
                                            <div>Total Tasks</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 summary-card" style="animation-delay: 0.1s;">
                            <div class="panel panel-success">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3"><i class="fa fa-check-circle fa-4x"></i></div>
                                        <div class="col-xs-9 text-right">
                                            <h3><?php echo e($reportData['summary']['completed']); ?></h3>
                                            <div>Completed</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 summary-card" style="animation-delay: 0.2s;">
                            <div class="panel panel-warning">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3"><i class="fa fa-spinner fa-4x"></i></div>
                                        <div class="col-xs-9 text-right">
                                            <h3><?php echo e($reportData['summary']['in_progress']); ?></h3>
                                            <div>In Progress</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 summary-card" style="animation-delay: 0.3s;">
                            <div class="panel panel-danger">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3"><i class="fa fa-times-circle fa-4x"></i></div>
                                        <div class="col-xs-9 text-right">
                                            <h3><?php echo e($reportData['summary']['incomplete']); ?></h3>
                                            <div>Incomplete</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $reportData['groups']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel panel-default report-group" style="margin-top: 20px;">
                            <div class="panel-heading" data-toggle="collapse" href="#collapse-<?php echo e(Str::slug($groupKey)); ?>">
                                <div class="panel-title-text">
                                    <h4 class="panel-title" style="margin-right: 15px; font-weight:700;"><?php echo e($groupKey); ?></h4>
                                    <h5 style="margin:0;">(Tasks: <?php echo e($group['total']); ?> | Completed: <strong><?php echo e($group['completion_rate']); ?>%</strong>)</h5>
                                </div>

                                <form action="<?php echo e(route('admin.reports.index')); ?>" method="POST" target="_blank" onclick="event.stopPropagation();">
                                    <?php echo csrf_field(); ?>
                                    <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="section_group_key" value="<?php echo e($groupKey); ?>">
                                    <button type="submit" name="export_section_csv" value="1" class="action-btn section csv">
                                        <i class="fa fa-download"></i> Export CSV
                                    </button>
                                </form>
                            </div>

                            <div id="collapse-<?php echo e(Str::slug($groupKey)); ?>" class="panel-collapse collapse in">
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped task-report-table">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>Description</th>
                                                    <th>Assigned To</th>
                                                    <th>Start Time</th>
                                                    <th>End Time</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $group['tasks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($task->t_title); ?></td>
                                                        <td class="description-cell"><?php echo e(Str::limit($task->t_description, 50)); ?></td>
                                                        <td><?php echo e($task->assigned_to_name); ?></td>
                                                        <td><?php echo e($task->t_start_time); ?></td>
                                                        <td><?php echo e($task->t_end_time); ?></td>
                                                        <td>
                                                            <?php if($task->status == 2): ?>
                                                                <span class="label label-success">Completed</span>
                                                            <?php elseif($task->status == 1): ?>
                                                                <span class="label label-warning">In Progress</span>
                                                            <?php else: ?>
                                                                <span class="label label-danger">Incomplete</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function toggleDateInputs(val) {
    document.getElementById('end-date-div').style.display = (val === 'custom') ? 'block' : 'none';
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>