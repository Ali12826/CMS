<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Page Header -->
    <div class="row">
        <div class="col-md-12">
            <h3 style="margin-top: 0; margin-bottom: 20px;">
                <i class="fa fa-pencil-square-o"></i> Edit Task
                <small>#<?php echo e($task->task_id); ?></small>
            </h3>
        </div>
    </div>

    <!-- Main Content Row -->
    <div class="row">
        <div class="col-md-8 col-md-offset-2"> <!-- Centered Form -->

            <!-- Standard Bootstrap Panel -->
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Update Task Information</h3>
                </div>

                <div class="panel-body">

                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('tasks.update', $task->task_id)); ?>" method="POST" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Department</label>
                            <div class="col-sm-9">
                                <select class="form-control" name="dept_id" required>
                                    <option value="">Select Department</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dept->dept_id); ?>" <?php echo e($task->dept_id == $dept->dept_id ? 'selected' : ''); ?>>
                                            <?php echo e($dept->dept_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Task Title <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="t_title" value="<?php echo e(old('t_title', $task->t_title)); ?>" required>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Start Time <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control datetimepicker" name="t_start_time" value="<?php echo e(old('t_start_time', $task->t_start_time)); ?>" required>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label class="col-sm-3 control-label">End Time <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control datetimepicker" name="t_end_time" value="<?php echo e(old('t_end_time', $task->t_end_time)); ?>" required>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Status <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control" name="status" required>
                                    <option value="0" <?php echo e($task->status == 0 ? 'selected' : ''); ?>>Incomplete</option>
                                    <option value="1" <?php echo e($task->status == 1 ? 'selected' : ''); ?>>In Progress</option>
                                    <option value="2" <?php echo e($task->status == 2 ? 'selected' : ''); ?>>Complete</option>
                                </select>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Description</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="t_description" rows="3"><?php echo e(old('t_description', $task->t_description)); ?></textarea>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <div class="col-sm-9 col-sm-offset-3">
                                <button type="submit" class="btn btn-primary">Update Task</button>
                                <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-default">Cancel</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/tasks/edit.blade.php ENDPATH**/ ?>