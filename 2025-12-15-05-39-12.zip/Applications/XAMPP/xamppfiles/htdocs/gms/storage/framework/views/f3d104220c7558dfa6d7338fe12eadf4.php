<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/images/logo2.png')); ?>">

    <title>Login | <?php echo e(config('app.name', 'GIGA MALL GMS')); ?></title>

    <script src="https://cdn.tailwindcss.com"></script>

    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">

    <style>
        /* --- THEME VARIABLES --- */
        :root {
            --primary-color: #0A2342;
            --secondary-color: #C8A951;
            --soft-bg: #f5f7fa;
            --text-primary: #0A2342;
        }
        body { font-family: 'Inter', sans-serif; background-color: var(--soft-bg); color: var(--text-primary); }
        .text-gradient { background-image: linear-gradient(to right, var(--primary-color), var(--secondary-color)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .soft-section { background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%); border: 1px solid #E2E8F0; border-radius: 20px; padding: 2.5rem; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08); }
        .glass-header { background-color: rgba(255, 255, 255, 0.95); backdrop-filter: blur(25px); border-bottom: 1px solid rgba(200, 169, 81, 0.3); box-shadow: 0 4px 15px rgba(10, 35, 66, 0.1); }

        /* --- INPUT STYLES --- */
        .input-group { position: relative; margin-bottom: 1.75rem; }
        .input-label { position: absolute; left: 3.25rem; top: 1rem; font-size: 1rem; font-weight: 500; color: #718096; pointer-events: none; transition: all 0.3s; background-color: white; padding: 0 0.25rem; z-index: 5; }
        .input-group:focus-within .input-label, .input-group .form-input:not(:placeholder-shown) ~ .input-label { top: -0.6rem; left: 2.75rem; font-size: 0.75rem; font-weight: 600; color: var(--secondary-color); }
        .input-icon { position: absolute; left: 1.25rem; top: 50%; transform: translateY(-50%); color: #A0AEC0; transition: color 0.3s; z-index: 10; }
        .input-group:focus-within .input-icon { color: var(--secondary-color); }
        .password-toggle { position: absolute; right: 1.25rem; top: 50%; transform: translateY(-50%); cursor: pointer; color: #A0AEC0; transition: all 0.3s; z-index: 10; padding: 0.25rem; border-radius: 0.25rem; }
        .password-toggle:hover { color: var(--secondary-color); background-color: rgba(200, 169, 81, 0.1); }
        .form-input { width: 100%; padding: 1rem 1.25rem 1rem 3.25rem; border: 2px solid #E2E8F0; border-radius: 0.875rem; background-color: white; font-size: 1rem; transition: all 0.3s; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05); outline: none; }
        .form-input:focus { border-color: var(--secondary-color); box-shadow: 0 0 0 4px rgba(200, 169, 81, 0.12); transform: translateY(-1px); }

        /* --- ALERTS & BUTTONS --- */
        .error-message { background: linear-gradient(135deg, rgba(245, 101, 101, 0.1), rgba(245, 101, 101, 0.05)); border: 1px solid rgba(245, 101, 101, 0.3); border-radius: 0.75rem; color: #742A2A; padding: 1rem 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.875rem; font-size: 0.875rem; }
        .btn-primary { padding: 1rem; border-radius: 0.875rem; font-size: 1rem; font-weight: 600; transition: all 0.3s; }
    </style>
</head>
<body class="min-h-screen antialiased">

    <header class="p-4 sticky top-0 z-[100] glass-header">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            
            <a href="<?php echo e(url('/')); ?>" class="flex items-center space-x-3 text-2xl font-black cursor-pointer transition duration-300 hover:scale-110">

                
                <img src="<?php echo e(asset('storage/images/logo2.png')); ?>"
                     class="w-16 h-auto md:w-20 object-contain"
                     alt="GMS Logo">

                <span class="font-extrabold tracking-tight text-3xl text-gradient">GMS</span>
            </a>
            <nav class="hidden md:flex items-center space-x-2">
                
                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="px-7 py-2 rounded-lg text-sm font-semibold shadow-md" style="background-color: var(--secondary-color); color: var(--primary-color); transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
                        <i data-lucide="user-plus" class="w-5 h-5 inline mr-1 -mt-0.5"></i> Register
                    </a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="flex-grow flex items-center justify-center py-12 px-4">
        <div class="max-w-md w-full soft-section">
            <div class="text-center mb-8">
                <h2 class="text-3xl font-extrabold text-gradient">Secure Login</h2>
                <p class="mt-2 text-sm text-gray-600">Access the GMS Command Interface</p>
            </div>

            <?php if($errors->any()): ?>
                <div class="error-message">
                    <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0"></i>
                    <span><?php echo e($errors->first()); ?></span>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded flex items-center gap-2">
                    <i data-lucide="check-circle" class="w-4 h-4"></i>
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('login')); ?>" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?> <div class="input-group">
                    <i data-lucide="user" class="input-icon w-5 h-5"></i>
                    <input type="text" class="form-input" id="username" name="username" placeholder=" Username" required autofocus value="<?php echo e(old('username')); ?>"/>
                    <label for="username" class="input-label">Username</label>
                </div>

                <div class="input-group">
                    <i data-lucide="lock" class="input-icon w-5 h-5"></i>
                    
                    <input type="password" class="form-input" id="password" name="admin_password" placeholder="Password" required/>
                    <label for="password" class="input-label">Password</label>
                    <span class="password-toggle" id="togglePassword">
                        <i data-lucide="eye" class="w-5 h-5" id="toggleIcon"></i>
                    </span>
                </div>

                <div class="flex justify-between items-center mb-6 text-sm">
                    <label class="flex items-center gap-2 text-gray-600 font-medium cursor-pointer">
                        <input type="checkbox" name="remember_me" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"/>
                        <span>Remember me</span>
                    </label>
                </div>

                <button type="submit" class="btn-primary w-full text-white shadow-lg flex justify-center items-center" style="background-color: var(--primary-color);">
                    <i data-lucide="log-in" class="w-5 h-5 inline mr-2"></i>
                    <span>Login to Dashboard</span>
                </button>

                <div class="text-center mt-6">
                    <p class="text-sm text-gray-600">
                        Don't have an account?
                        <a href="<?php echo e(route('register')); ?>" class="font-bold hover:underline" style="color: var(--secondary-color);">Register here</a>
                    </p>
                </div>
            </form>
        </div>
    </main>

    <footer class="py-8 bg-gray-900">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="flex justify-center items-center space-x-2 text-xl font-bold mb-4 text-white">

                
                <img src="<?php echo e(asset('storage/images/logo7.png')); ?>"
                     alt="GMS Logo"
                     class="w-20 h-auto object-contain">

                <span class="text-gray-200 font-extrabold text-2xl">GMS</span>
            </div>
            <p class="text-sm text-gray-400">&copy; <?php echo e(date('Y')); ?> GMS. For GIGA MALL IT Operations.</p>
        </div>
    </footer>

    <script>
        // Initialize Icons
        lucide.createIcons();

        // Password Toggle Logic
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('toggleIcon');

        if (togglePassword) {
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);

                // Toggle Eye Icon
                toggleIcon.setAttribute('data-lucide', type === 'text' ? 'eye-off' : 'eye');
                lucide.createIcons(); // Re-render icons after changing attribute
            });
        }
    </script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/auth/login.blade.php ENDPATH**/ ?>