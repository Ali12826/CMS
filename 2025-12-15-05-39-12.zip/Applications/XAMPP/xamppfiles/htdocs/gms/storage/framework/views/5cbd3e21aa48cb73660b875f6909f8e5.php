<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | GIGA MALL GMS</title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/images/logo2.png')); ?>">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #0A2342;
            --secondary-color: #C8A951;
            --soft-bg: #f5f7fa;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--soft-bg);
            color: var(--primary-color);
        }
        .text-gradient {
            background-image: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .soft-section {
            background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%);
            border: 1px solid #E2E8F0;
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
        }
        .glass-header {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(25px);
            border-bottom: 1px solid rgba(200, 169, 81, 0.3);
            box-shadow: 0 4px 15px rgba(10, 35, 66, 0.1);
        }
        /* Input & Form Styling */
        .input-group { position: relative; margin-bottom: 1.75rem; }
        .input-label {
            position: absolute; left: 3.25rem; top: 1rem; font-size: 1rem; font-weight: 500;
            color: #718096; pointer-events: none; transition: all 0.3s;
            background-color: white; padding: 0 0.25rem; z-index: 5;
        }
        .input-group:focus-within .input-label,
        .input-group .form-input:not(:placeholder-shown) ~ .input-label,
        .input-group .form-select:valid ~ .input-label {
            top: -0.6rem; left: 2.75rem; font-size: 0.75rem; font-weight: 600; color: var(--secondary-color);
        }
        .input-icon {
            position: absolute; left: 1.25rem; top: 50%; transform: translateY(-50%);
            color: #A0AEC0; z-index: 10;
        }
        .input-group:focus-within .input-icon { color: var(--secondary-color); }
        .password-toggle {
            position: absolute; right: 1.25rem; top: 50%; transform: translateY(-50%);
            cursor: pointer; color: #A0AEC0; z-index: 10; padding: 0.25rem; border-radius: 0.25rem;
        }
        .password-toggle:hover { color: var(--secondary-color); background-color: rgba(200, 169, 81, 0.1); }
        .form-input, .form-select {
            width: 100%; padding: 1rem 1.25rem 1rem 3.25rem; border: 2px solid #E2E8F0;
            border-radius: 0.875rem; background-color: white; font-size: 1rem;
            transition: all 0.3s; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05); outline: none;
        }
        .form-input:focus, .form-select:focus {
            border-color: var(--secondary-color); box-shadow: 0 0 0 4px rgba(200, 169, 81, 0.12);
            transform: translateY(-1px);
        }
        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23A0AEC0'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
            background-repeat: no-repeat; background-position: right 1rem center;
            background-size: 1.25rem; padding-right: 3rem;
        }
        .error-message {
            background: linear-gradient(135deg, rgba(245, 101, 101, 0.1), rgba(245, 101, 101, 0.05));
            border: 1px solid rgba(245, 101, 101, 0.3); border-radius: 0.75rem;
            color: #742A2A; padding: 1rem 1.25rem; margin-bottom: 1.5rem;
            display: flex; align-items: center; gap: 0.875rem; font-size: 0.875rem;
        }
        .btn-primary {
            padding: 1rem; border-radius: 0.875rem; font-size: 1rem; font-weight: 600; transition: all 0.3s;
        }
    </style>
</head>
<body class="min-h-screen antialiased">

    <header class="p-4 sticky top-0 z-50 glass-header">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <a href="/" class="flex items-center space-x-3 text-2xl font-black cursor-pointer">
             <img src="<?php echo e(asset('storage/images/logo2.png')); ?>"
                     class="w-16 h-auto md:w-20 object-contain"
                     alt="GMS Logo">
                <span class="font-extrabold tracking-tight text-3xl text-gradient">GMS</span>
            </a>

            <nav class="hidden md:flex items-center space-x-2">
                <a href="<?php echo e(route('login')); ?>" class="px-7 py-2 rounded-lg text-sm font-semibold shadow-md text-white" style="background-color: var(--primary-color);">
                    <i data-lucide="lock" class="w-5 h-5 inline mr-1 -mt-0.5"></i> Login
                </a>
            </nav>
        </div>
    </header>

    <main class="flex-grow flex items-center justify-center py-12 px-4">
        <div class="max-w-md w-full soft-section">

            <div class="text-center mb-8">
                <h2 class="text-3xl font-extrabold text-gradient">Create Account</h2>
                <p class="mt-2 text-sm text-gray-600">Register for GMS Employee Access</p>
            </div>

            <?php if($errors->any()): ?>
                <div class="error-message">
                    <i data-lucide="alert-circle" class="w-5 h-5 flex-shrink-0"></i>
                    <span><?php echo e($errors->first()); ?></span>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('register')); ?>" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?>

                <div class="input-group">
                    <i data-lucide="user" class="input-icon w-5 h-5"></i>
                    <input type="text" class="form-input" id="fullname" name="fullname" placeholder="Enter your full name" required value="<?php echo e(old('fullname')); ?>"/>
                    <label for="fullname" class="input-label">Full Name</label>
                </div>

                <div class="input-group">
                    <i data-lucide="at-sign" class="input-icon w-5 h-5"></i>
                    <input type="text" class="form-input" id="username" name="username" placeholder="Choose a username" required pattern="[a-zA-Z0-9_-]{3,20}" value="<?php echo e(old('username')); ?>"/>
                    <label for="username" class="input-label">Username</label>
                </div>

                <div class="input-group">
                    <i data-lucide="phone" class="input-icon w-5 h-5"></i>
                    <input type="tel" class="form-input" id="contact" name="contact" placeholder="Enter your contact number" required value="<?php echo e(old('contact')); ?>"/>
                    <label for="contact" class="input-label">Contact Number</label>
                </div>

                <div class="input-group">
                    <i data-lucide="briefcase" class="input-icon w-5 h-5"></i>
                    <select class="form-select" id="dept_id" name="dept_id" required>
                        <option value="" disabled selected></option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dept->dept_id); ?>" <?php echo e(old('dept_id') == $dept->dept_id ? 'selected' : ''); ?>>
                                <?php echo e($dept->dept_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="dept_id" class="input-label">Department</label>
                </div>

                <div class="input-group">
                    <i data-lucide="lock" class="input-icon w-5 h-5"></i>
                    <input type="password" class="form-input" id="password" name="password" placeholder="Create a password" required minlength="6"/>
                    <label for="password" class="input-label">Password</label>
                    <span class="password-toggle" id="togglePassword">
                        <i data-lucide="eye" class="w-5 h-5" id="toggleIcon"></i>
                    </span>
                </div>

                <div class="input-group">
                    <i data-lucide="lock" class="input-icon w-5 h-5"></i>
                    <input type="password" class="form-input" id="password_confirmation" name="password_confirmation" placeholder="Confirm your password" required minlength="6"/>
                    <label for="password_confirmation" class="input-label">Confirm Password</label>
                    <span class="password-toggle" id="toggleConfirmPassword">
                        <i data-lucide="eye" class="w-5 h-5" id="toggleConfirmIcon"></i>
                    </span>
                </div>

                <button type="submit" class="btn-primary w-full text-white shadow-lg" style="background-color: var(--primary-color);">
                    <i data-lucide="user-plus" class="w-5 h-5 inline mr-2"></i>
                    <span>Create Account</span>
                </button>

                <div class="text-center mt-6">
                    <p class="text-sm text-gray-600">
                        Already have an account?
                        <a href="<?php echo e(route('login')); ?>" class="font-bold hover:underline" style="color: var(--secondary-color);">Login here</a>
                    </p>
                </div>
            </form>
        </div>
    </main>

    <footer class="py-8 bg-gray-900">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="flex justify-center items-center space-x-2 mb-4 text-white">
                 <img src="<?php echo e(asset('storage/images/logo7.png')); ?>"
                     alt="GMS Logo"
                     class="w-20 h-auto object-contain">
                <span class="text-gray-200 font-extrabold text-2xl">GMS</span>
            </div>
            <p class="text-sm text-gray-400">&copy; 2025 GMS. For GIGA MALL IT Department</p>
        </div>
    </footer>

    <script>
        // Initialize Icons
        lucide.createIcons();

        // Password toggle for password field
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('toggleIcon');

        if (togglePassword) {
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                toggleIcon.setAttribute('data-lucide', type === 'text' ? 'eye-off' : 'eye');
                lucide.createIcons();
            });
        }

        // Password toggle for confirm password field
        const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
        const confirmPasswordInput = document.getElementById('password_confirmation');
        const toggleConfirmIcon = document.getElementById('toggleConfirmIcon');

        if (toggleConfirmPassword) {
            toggleConfirmPassword.addEventListener('click', function() {
                const type = confirmPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                confirmPasswordInput.setAttribute('type', type);
                toggleConfirmIcon.setAttribute('data-lucide', type === 'text' ? 'eye-off' : 'eye');
                lucide.createIcons();
            });
        }
    </script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/auth/register.blade.php ENDPATH**/ ?>