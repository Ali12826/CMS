<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <div class="row">
        <div class="col-md-12">
            <h3 style="margin-top: 0; margin-bottom: 20px;">
                <i class="fa fa-plus-circle"></i> Create New Task
            </h3>
        </div>
    </div>

    
    <div class="row">
        
        <div class="col-md-8 col-md-offset-2">

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-6">
                            <h3 class="panel-title" style="line-height: 2;">Task Form</h3>
                        </div>
                        <div class="col-xs-6 text-right">
                            <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-default btn-xs">
                                <i class="fa fa-arrow-left"></i> Back to List
                            </a>
                        </div>
                    </div>
                </div>

                <div class="panel-body">
                    
                    <form action="<?php echo e(route('tasks.store')); ?>" method="POST" class="form-horizontal" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        
                        <div class="form-group <?php echo e($errors->has('t_title') ? 'has-error' : ''); ?>">
                            <label for="t_title" class="col-sm-3 control-label">Task Title <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="t_title" name="t_title" value="<?php echo e(old('t_title')); ?>" placeholder="Enter task title" required>
                                <?php if($errors->has('t_title')): ?>
                                    <span class="help-block"><?php echo e($errors->first('t_title')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group <?php echo e($errors->has('dept_id') ? 'has-error' : ''); ?>">
                            <label for="dept_id" class="col-sm-3 control-label">Department <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control" id="dept_id" name="dept_id" required>
                                    <option value="" selected>Select Department</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dept->dept_id); ?>" <?php echo e(old('dept_id') == $dept->dept_id ? 'selected' : ''); ?>>
                                            <?php echo e($dept->dept_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('dept_id')): ?>
                                    <span class="help-block"><?php echo e($errors->first('dept_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group <?php echo e($errors->has('t_user_id') ? 'has-error' : ''); ?>">
                            <label for="t_user_id" class="col-sm-3 control-label">Assign To <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select class="form-control" id="t_user_id" name="t_user_id" required>
                                    <option value="" selected>Select Employee</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <option value="<?php echo e($emp->user_id); ?>"
                                                data-dept-id="<?php echo e($emp->dept_id); ?>"
                                                <?php echo e(old('t_user_id') == $emp->user_id ? 'selected' : ''); ?>>
                                            <?php echo e($emp->fullname); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('t_user_id')): ?>
                                    <span class="help-block"><?php echo e($errors->first('t_user_id')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group <?php echo e($errors->has('t_start_time') ? 'has-error' : ''); ?>">
                            <label for="t_start_time" class="col-sm-3 control-label">Start Time <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    <input type="text" class="form-control datetimepicker" id="t_start_time" name="t_start_time" value="<?php echo e(old('t_start_time')); ?>" placeholder="Select Start Date & Time" required>
                                </div>
                                <?php if($errors->has('t_start_time')): ?>
                                    <span class="help-block"><?php echo e($errors->first('t_start_time')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group <?php echo e($errors->has('t_end_time') ? 'has-error' : ''); ?>">
                            <label for="t_end_time" class="col-sm-3 control-label">Due Date <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    <input type="text" class="form-control datetimepicker" id="t_end_time" name="t_end_time" value="<?php echo e(old('t_end_time')); ?>" placeholder="Select End Date & Time" required>
                                </div>
                                <?php if($errors->has('t_end_time')): ?>
                                    <span class="help-block"><?php echo e($errors->first('t_end_time')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group <?php echo e($errors->has('t_description') ? 'has-error' : ''); ?>">
                            <label for="t_description" class="col-sm-3 control-label">Description</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" id="t_description" name="t_description" rows="4" placeholder="Enter task details..."><?php echo e(old('t_description')); ?></textarea>
                                <?php if($errors->has('t_description')): ?>
                                    <span class="help-block"><?php echo e($errors->first('t_description')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-check"></i> Create Task
                                </button>
                                <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-default">Cancel</a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 1. Initialize Datepicker
        flatpickr(".datetimepicker", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            time_24hr: true,
            allowInput: true,
            defaultDate: new Date()
        });

        // 2. Strict Employee Filtering
        const deptSelect = document.getElementById('dept_id');
        const empSelect = document.getElementById('t_user_id');

        // Clone all original options immediately so we can rebuild the list later
        // We use Array.from to get a clean array of node copies
        const allEmployees = Array.from(empSelect.options).map(opt => opt.cloneNode(true));

        function filterEmployees() {
            const selectedDeptId = deptSelect.value;
            const previousSelectedUser = empSelect.value;

            // Clear current options completely (removes them from DOM)
            empSelect.innerHTML = '';

            // Rebuild list based on logic
            allEmployees.forEach(function(option) {
                // Always add the "Select Employee" placeholder
                if (option.value === "") {
                    empSelect.appendChild(option);
                    return;
                }

                // Only add employees that match the selected department
                const employeeDeptId = option.getAttribute('data-dept-id');
                if (selectedDeptId && employeeDeptId == selectedDeptId) {
                    empSelect.appendChild(option);
                }
            });

            // Try to restore previous selection if it is still valid in the new list
            // (e.g. if we are just re-running on load and the data is correct)
            empSelect.value = previousSelectedUser;

            // If the previous value is no longer in the list (index is -1), reset to placeholder
            if (empSelect.selectedIndex === -1) {
                empSelect.selectedIndex = 0;
            }
        }

        // Run filter when Department changes
        deptSelect.addEventListener('change', filterEmployees);

        // Run filter immediately on load
        filterEmployees();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/tasks/create.blade.php ENDPATH**/ ?>