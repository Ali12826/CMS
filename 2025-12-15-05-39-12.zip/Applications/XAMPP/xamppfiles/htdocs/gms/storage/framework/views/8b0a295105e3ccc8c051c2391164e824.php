<?php $__env->startSection('head'); ?>
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/images/logo12.png')); ?>?v=<?php echo e(time()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default" style="margin-bottom: 20px; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,0.05); border-top: 3px solid #3c8dbc;">
                <div class="panel-body" style="padding: 15px 20px;">
                    <div class="row">
                        <div class="col-sm-6" style="display: flex; align-items: center;">
                            

                            <h3 style="margin: 0; font-weight: 600; color: #444; line-height: 1.2;">
                                <i class="fa fa-tasks" style="color: #3c8dbc; margin-right: 5px;"></i> Task Management
                            </h3>
                        </div>
                        <div class="col-sm-6 text-right">
                            <?php if(auth()->guard()->check()): ?>
                                <div style="display: inline-block; vertical-align: middle;">
                                    <span class="text-muted" style="margin-right: 15px; font-size: 13px;">
                                        <i class="fa fa-user-circle"></i> Welcome, <strong style="color: #333;"><?php echo e(Auth::user()->fullname ?? Auth::user()->name); ?></strong>
                                    </span>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" style="border-radius: 3px; font-weight: 600;">
                                            <i class="fa fa-power-off"></i> Logout
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa fa-sign-in"></i> Log in
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php
        $currUser = Auth::user();
        $isAdmin  = $currUser->user_role == 1; // 1 = Admin

        // Get Filter Requests
        $assignFilter = request('assign_filter', 'to_me'); // Default to 'to_me'
        if($isAdmin && !request()->has('assign_filter')) {
            $assignFilter = 'all'; // Default 'all' for admin
        }

        // --- STATS QUERY ---
        $statsQuery = \DB::table('task_info');

        // Apply stats filtering based on Assignment Type
        if (!$isAdmin) {
             $statsQuery->where('t_user_id', $currUser->user_id);
        }

        $totalTasks = (clone $statsQuery)->count();
        $completed  = (clone $statsQuery)->where('status', 2)->count();
        $inProgress = (clone $statsQuery)->where('status', 1)->count();
        $incomplete = (clone $statsQuery)->where('status', 0)->count();

        // --- EMPLOYEE SIDEBAR QUERY ---
        $deptEmployees = \DB::table('tbl_admin')
            ->join('departments', 'tbl_admin.dept_id', '=', 'departments.dept_id')
            ->where('tbl_admin.dept_id', $currUser->dept_id)
            ->select('tbl_admin.user_id', 'tbl_admin.fullname', 'departments.dept_name')
            ->get();

        foreach($deptEmployees as $emp) {
            $activeTask = \DB::table('task_info')
                ->where('t_user_id', $emp->user_id)
                ->where('status', 1)
                ->first();
            $emp->is_busy = $activeTask ? true : false;
            $emp->current_task = $activeTask ? $activeTask->t_title : '';
        }
    ?>

    
    <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    <div style="font-size: 30px; font-weight: bold;"><?php echo e($totalTasks); ?></div>
                    <div style="font-size: 14px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px;">
                        <?php echo e($isAdmin ? 'Total Tasks' : 'My Tasks'); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading text-center">
                    <div style="font-size: 30px; font-weight: bold;"><?php echo e($completed); ?></div>
                    <div style="font-size: 14px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px;">Completed</div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="panel panel-warning">
                <div class="panel-heading text-center">
                    <div style="font-size: 30px; font-weight: bold;"><?php echo e($inProgress); ?></div>
                    <div style="font-size: 14px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px;">In Progress</div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="panel panel-danger">
                <div class="panel-heading text-center">
                    <div style="font-size: 30px; font-weight: bold;"><?php echo e($incomplete); ?></div>
                    <div style="font-size: 14px; opacity: 0.8; text-transform: uppercase; letter-spacing: 1px;">Incomplete</div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="panel panel-default">
        <div class="panel-body" style="background-color: #f9f9f9;">
            <form method="GET" action="<?php echo e(route('tasks.index')); ?>" id="filterForm">
                <div class="row">
                    
                    <div class="col-md-2 col-sm-6">
                        <div class="form-group" style="margin-bottom:0;">
                            <label class="small text-muted" style="margin-bottom:2px;">View Mode</label>
                            <select name="assign_filter" class="form-control" onchange="this.form.submit()">
                                <option value="to_me" <?php echo e($assignFilter == 'to_me' ? 'selected' : ''); ?>>Tasks Assigned To Me</option>
                                <option value="by_me" <?php echo e($assignFilter == 'by_me' ? 'selected' : ''); ?>>Tasks Assigned By Me</option>
                                <?php if($isAdmin): ?>
                                <option value="all" <?php echo e($assignFilter == 'all' ? 'selected' : ''); ?>>All Tasks (Admin)</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    
                    <div class="col-md-3 col-sm-6">
                        <div class="form-group" style="margin-bottom:0;">
                            <label class="small text-muted" style="margin-bottom:2px;">Search</label>
                            <input type="text" name="q" class="form-control" placeholder="Title..." value="<?php echo e(request('q')); ?>" onblur="this.form.submit()">
                        </div>
                    </div>

                    
                    <div class="col-md-2 col-sm-6">
                        <div class="form-group" style="margin-bottom:0;">
                            <label class="small text-muted" style="margin-bottom:2px;">Department</label>
                            <select name="dept_id" id="dept_id" class="form-control" onchange="this.form.submit()">
                                <option value="all">All Depts</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dept->dept_id); ?>" <?php echo e(request('dept_id') == $dept->dept_id ? 'selected' : ''); ?>>
                                        <?php echo e($dept->dept_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    
                    <div class="col-md-3 col-sm-6">
                        <div class="form-group" style="margin-bottom:0;">
                            <label class="small text-muted" style="margin-bottom:2px;">Employee</label>
                            <select name="employee_id" id="employee_id" class="form-control" onchange="this.form.submit()">
                                <option value="all">All Employees</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($emp->user_id); ?>"
                                            data-dept-id="<?php echo e($emp->dept_id); ?>"
                                            <?php echo e(request('employee_id') == $emp->user_id ? 'selected' : ''); ?>>
                                        <?php echo e($emp->fullname); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                     
                     <div class="col-md-2 col-sm-6">
                        <div class="form-group" style="margin-bottom:0;">
                            <label class="small text-muted" style="margin-bottom:2px;">Status</label>
                            <select name="status" class="form-control" onchange="this.form.submit()">
                                <option value="all">All Status</option>
                                <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>Incomplete</option>
                                <option value="1" <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>In Progress</option>
                                <option value="2" <?php echo e(request('status') === '2' ? 'selected' : ''); ?>>Completed</option>
                            </select>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row">

        
        <div class="col-md-8">
            <div class="row" style="margin-bottom: 15px;">
                <div class="col-md-6 col-xs-6">
                    <h4 style="margin: 0; color: #555;">Tasks List</h4>
                </div>
                <div class="col-md-6 col-xs-6 text-right">
                    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-success btn-sm">
                        <i class="fa fa-plus"></i> New Task
                    </a>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($tasks->isEmpty()): ?>
                <div class="alert alert-info">No tasks found matching your criteria.</div>
            <?php else: ?>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php
                        $showTask = true;
                        if($assignFilter == 'to_me') {
                            if($task->t_user_id != Auth::id()) $showTask = false;
                        }
                        elseif($assignFilter == 'by_me') {
                            if($task->assigned_by != Auth::id()) $showTask = false;
                        }
                    ?>

                    <?php if($showTask): ?>
                        <?php
                            $borderColor = '#d9534f';
                            $statusLabel = 'label-danger';
                            $statusText = 'Incomplete';

                            if($task->status == 1) {
                                $borderColor = '#f0ad4e';
                                $statusLabel = 'label-warning';
                                $statusText = 'In Progress';
                            } elseif($task->status == 2) {
                                $borderColor = '#5cb85c';
                                $statusLabel = 'label-success';
                                $statusText = 'Completed';
                            }
                        ?>

                        <div class="panel panel-default" style="border-left: 5px solid <?php echo e($borderColor); ?>; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h4 style="margin-top: 0; margin-bottom: 5px; font-weight: 600;">
                                            <?php echo e($task->t_title); ?>

                                            <span class="label <?php echo e($statusLabel); ?>" style="font-size: 10px; vertical-align: middle; margin-left: 10px;">
                                                <?php echo e($statusText); ?>

                                            </span>
                                        </h4>

                                        <p class="text-muted small" style="margin-bottom: 10px;">
                                            <i class="fa fa-building"></i> <?php echo e($task->department->dept_name ?? 'N/A'); ?> &nbsp;|&nbsp;
                                            <strong>To:</strong> <?php echo e($task->assignedTo->fullname ?? 'N/A'); ?> &nbsp;|&nbsp;
                                            <strong>By:</strong> <?php echo e($task->assignedBy->fullname ?? 'N/A'); ?>

                                        </p>

                                        <small style="color: #777;">
                                            <i class="fa fa-clock-o"></i> Start: <?php echo e(\Carbon\Carbon::parse($task->t_start_time)->format('M d, h:i A')); ?> <br>
                                            <i class="fa fa-flag"></i> Due: <?php echo e(\Carbon\Carbon::parse($task->t_end_time)->format('M d, h:i A')); ?>

                                        </small>
                                    </div>

                                    
                                    <div class="col-md-4 text-right" style="padding-top: 20px;">

                                        <a href="<?php echo e(route('tasks.show', $task->task_id)); ?>" class="btn btn-default btn-sm" title="View Details">
                                            <i class="fa fa-eye"></i> View
                                        </a>

                                        <a href="<?php echo e(route('tasks.edit', $task->task_id)); ?>" class="btn btn-primary btn-sm" title="Edit Task">
                                            <i class="fa fa-pencil"></i> Edit
                                        </a>

                                        <form action="<?php echo e(route('tasks.destroy', $task->task_id)); ?>" method="POST" style="display: inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Permanently" onclick="return confirm('Are you sure you want to PERMANENTLY delete this task? This action cannot be undone.');">
                                                <i class="fa fa-trash"></i> Delete
                                            </button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <div class="text-center">
                    <?php echo e($tasks->links()); ?>

                </div>
            <?php endif; ?>
        </div>

        
        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <i class="fa fa-users"></i> Department Status
                    </h3>
                </div>
                <ul class="list-group">
                    <?php $__currentLoopData = $deptEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <h5 style="margin: 0; font-size: 14px; font-weight: 600;"><?php echo e($emp->fullname); ?></h5>
                            <small class="text-muted"><?php echo e($emp->dept_name); ?></small>
                            <div style="margin-top: 5px;">
                                <?php if($emp->is_busy): ?>
                                    <span class="text-warning small">
                                        <i class="fa fa-spinner fa-spin"></i> Working on:
                                    </span>
                                    <small><?php echo e(\Illuminate\Support\Str::limit($emp->current_task, 25)); ?></small>
                                <?php else: ?>
                                    <span class="text-success small">
                                        <i class="fa fa-check-circle"></i> Available
                                    </span>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($deptEmployees->isEmpty()): ?>
                        <li class="list-group-item text-muted text-center">No employees found in your department.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function() {
        const deptSelect = document.getElementById('dept_id');
        const empSelect = document.getElementById('employee_id');

        // Clone all original options to restore them later
        const allEmployees = Array.from(empSelect.options).map(opt => opt.cloneNode(true));

        function filterEmployees() {
            const selectedDeptId = deptSelect.value;
            const currentEmpValue = empSelect.value;

            // Clear current options
            empSelect.innerHTML = '';

            allEmployees.forEach(function(option) {
                // Keep "All Employees" placeholder
                if (option.value === "all") {
                    empSelect.appendChild(option);
                    return;
                }

                const employeeDeptId = option.getAttribute('data-dept-id');

                if (selectedDeptId === 'all' || !selectedDeptId) {
                    empSelect.appendChild(option);
                } else if (employeeDeptId == selectedDeptId) {
                    empSelect.appendChild(option);
                }
            });

            empSelect.value = currentEmpValue;

            if (empSelect.selectedIndex === -1) {
                empSelect.value = "all";
            }
        }

        filterEmployees();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/tasks/index.blade.php ENDPATH**/ ?>