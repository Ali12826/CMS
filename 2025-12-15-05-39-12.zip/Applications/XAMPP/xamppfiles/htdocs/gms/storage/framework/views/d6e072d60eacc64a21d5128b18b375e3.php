<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'GIGA MALL GMS')); ?></title>

    
    <link rel="icon" type="image/png" href="<?php echo e(asset('storage/images/logo12.png')); ?>?v=<?php echo e(time()); ?>">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('storage/images/logo12.png')); ?>?v=<?php echo e(time()); ?>">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;700&family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
</head>
    <style>
        /* --- CUSTOM THEME VARIABLES (Giga Mall Navy & Gold) --- */
        :root {
            --primary-color: #0A2342; /* Navy Blue */
            --primary-dark: #071930;
            --secondary-color: #C8A951; /* Luxury Gold */
            --secondary-dark: #A68B42;
            --portal-color: #0A2342;
            --register-color: #C8A951;
            --soft-bg: #f5f7fa;
            --soft-border: #e2e8f0;
            --text-primary: #0A2342;
            --text-secondary: #A68B42;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--soft-bg);
            color: var(--text-primary);
            overflow-x: hidden;
        }

        /* --- UTILITIES --- */
        .text-gradient {
            background-image: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* --- BUTTONS --- */
        .btn-portal, .btn-register {
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .btn-portal:hover, .btn-register:hover {
            transform: translateY(-4px) scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        /* --- CARDS --- */
        .soft-section {
            background-color: white;
            border: 1px solid var(--soft-border);
            border-radius: 16px;
            padding: 2rem;
            transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
        }

        .soft-section:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            transform: translateY(-10px);
            border-color: var(--secondary-color);
        }

        /* --- HEADER --- */
        .glass-header {
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(25px);
            /* Gold border to match logo surroundings */
            border-bottom: 3px solid rgba(200, 169, 81, 0.8);
            box-shadow: 0 6px 25px rgba(10, 35, 66, 0.15);
        }

        /* --- ANIMATIONS --- */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-fade-in-up {
            animation: fadeInUp 1.4s ease-out forwards;
        }

        /* --- NAVIGATION --- */
        .nav-link {
            position: relative;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: var(--primary-color) !important;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -4px;
            left: 50%;
            transform: translateX(-50%);
            background-color: var(--secondary-color);
            transition: width 0.3s ease;
        }
        .nav-link:hover::after {
            width: 100%;
        }

        /* --- DROPDOWN --- */
        .dropdown { position: relative; display: inline-block; }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #ffffff;
            min-width: 180px;
            box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
            z-index: 10;
            border-radius: 8px;
            border: 1px solid var(--soft-border);
            padding: 8px 0;
            top: 100%;
        }
        .dropdown:hover .dropdown-content { display: block; }
        .dropdown-content a {
            color: var(--primary-color);
            padding: 10px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover { background-color: var(--soft-bg); color: var(--secondary-dark); }

        /* --- MOBILE MENU --- */
        #mobile-menu {
            transition: max-height 0.3s ease-in-out, opacity 0.3s ease-in-out;
            max-height: 0;
            opacity: 0;
            overflow: hidden;
            background-color: white;
            border-bottom: 2px solid var(--secondary-color);
        }
        #mobile-menu.open {
            max-height: 500px; /* Arbitrary large height */
            opacity: 1;
        }
    </style>
</head>
<body class="antialiased">

    <header class="glass-header fixed w-full z-50 top-0">
        <nav class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20 md:h-24">

                <a href="<?php echo e(url('/')); ?>" class="flex items-center space-x-3 group">
                    
                    <img src="<?php echo e(asset('storage/images/logo2.png')); ?>"
                         alt="GMS Logo"
                         class="w-16 h-auto md:w-20 object-contain transition-transform transform group-hover:scale-105">

                    <span class="font-extrabold text-2xl md:text-3xl text-gradient tracking-tight">GMS</span>
                </a>

                <div class="hidden md:flex items-center space-x-6 lg:space-x-8">
                    <a href="#features" class="nav-link font-medium" style="color: var(--text-secondary);">Features</a>
                    <a href="#workflow" class="nav-link font-medium" style="color: var(--text-secondary);">How It Works</a>

                    <div class="dropdown">
                        <button class="nav-link font-medium flex items-center" style="color: var(--text-secondary);">
                            More <i data-lucide="chevron-down" class="w-4 h-4 ml-1"></i>
                        </button>
                        <div class="dropdown-content">
                            <a href="#">Tech Setup</a>
                            <a href="#">About Giga</a>
                            <a href="#">Success Stories</a>
                        </div>
                    </div>

                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn-register px-5 py-2 rounded-lg font-semibold flex items-center space-x-1" style="background-color: var(--register-color); color: var(--primary-dark);">
                            <i data-lucide="user-plus" class="w-4 h-4"></i>
                            <span>Register</span>
                        </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('login')); ?>" class="btn-portal px-5 py-2 rounded-lg font-semibold flex items-center space-x-1" style="background-color: var(--portal-color); color: white;">
                        <i data-lucide="log-in" class="w-4 h-4"></i>
                        <span>Login</span>
                    </a>
                </div>

                <div class="md:hidden flex items-center">
                    <button id="mobile-menu-btn" class="focus:outline-none">
                        <i data-lucide="menu" class="w-8 h-8" style="color: var(--primary-color);"></i>
                    </button>
                </div>
            </div>
        </nav>

        <div id="mobile-menu" class="md:hidden shadow-lg">
            <div class="px-4 pt-2 pb-6 space-y-2">
                <a href="#features" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">Features</a>
                <a href="#workflow" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">How It Works</a>

                <div class="mt-4 border-t border-gray-200 pt-4 flex flex-col space-y-3">
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="w-full text-center px-4 py-3 rounded-lg font-bold" style="background-color: var(--register-color); color: var(--primary-dark);">
                            Register
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('login')); ?>" class="w-full text-center px-4 py-3 rounded-lg font-bold" style="background-color: var(--portal-color); color: white;">
                        Login
                    </a>
                </div>
            </div>
        </div>
    </header>

    <section class="pt-32 md:pt-40 lg:pt-48 pb-20 md:pb-24 bg-gradient-to-b from-white to-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl md:text-6xl lg:text-7xl font-extrabold mb-6 text-gradient animate-fade-in-up">
                GIGA MALL GMS
            </h1>
            <p class="text-xl md:text-2xl lg:text-3xl font-medium max-w-3xl mx-auto mb-10 md:mb-12 leading-relaxed animate-fade-in-up" style="animation-delay: 0.3s; color: #4b5563;">
                The official management tool designed to streamline daily operations and enhance productivity.
            </p>
            <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 animate-fade-in-up" style="animation-delay: 0.6s;">
                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="btn-register px-8 py-4 rounded-xl text-lg font-bold shadow-xl flex items-center justify-center" style="background-color: var(--register-color); color: var(--primary-dark);">
                        <i data-lucide="user-plus" class="w-5 h-5 mr-2"></i> Register Now
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('login')); ?>" class="btn-portal px-8 py-4 rounded-xl text-lg font-bold shadow-xl flex items-center justify-center" style="background-color: var(--portal-color); color: white;">
                    <i data-lucide="log-in" class="w-5 h-5 mr-2"></i> Log into GMS
                </a>
            </div>
        </div>
    </section>

    <section id="features" class="py-16 md:py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-3xl md:text-5xl font-extrabold text-center mb-12" style="color: var(--text-primary);">Core Capabilities</h2>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="soft-section text-center">
                    <div class="flex justify-center">
                        <i data-lucide="check-circle" class="w-12 h-12 mb-4" style="color: var(--secondary-color);"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-2">Task Management</h3>
                    <p class="text-gray-600">Streamline workflows from initiation to completion.</p>
                </div>

                <div class="soft-section text-center">
                    <div class="flex justify-center">
                        <i data-lucide="bar-chart-2" class="w-12 h-12 mb-4" style="color: var(--secondary-color);"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-2">Team Analytics</h3>
                    <p class="text-gray-600">Real-time insights into team performance.</p>
                </div>

                <div class="soft-section text-center">
                    <div class="flex justify-center">
                        <i data-lucide="filter" class="w-12 h-12 mb-4" style="color: var(--secondary-color);"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-2">Smart Filtering</h3>
                    <p class="text-gray-600">Dynamic data sorting for quick access.</p>
                </div>

                <div class="soft-section text-center">
                    <div class="flex justify-center">
                        <i data-lucide="shield" class="w-12 h-12 mb-4" style="color: var(--secondary-color);"></i>
                    </div>
                    <h3 class="text-xl font-bold mb-2">Secure Core</h3>
                    <p class="text-gray-600">Enterprise-grade security standards.</p>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
            <div class="mb-6 md:mb-0 text-center md:text-left">
                <span class="text-2xl font-bold text-gradient">GMS</span>
                <p class="text-gray-400 mt-2 text-sm">© <?php echo e(date('Y')); ?> Giga Mall. All rights reserved.</p>
            </div>
            <div class="flex space-x-6">
                <a href="#" class="text-gray-400 hover:text-white transition">Privacy Policy</a>
                <a href="#" class="text-gray-400 hover:text-white transition">Terms of Service</a>
                <a href="#" class="text-gray-400 hover:text-white transition">Contact</a>
            </div>
        </div>
    </footer>

    <script>
        // Initialize Lucide Icons
        lucide.createIcons();

        // Mobile Menu Toggle Logic
        const menuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');

        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('open');
        });
    </script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gms/resources/views/landing.blade.php ENDPATH**/ ?>