
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(100) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'HR'),(2,'IT'),(3,'Finance'),(4,'Billing'),(5,'Admin'),(6,'Other');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_11_26_061700_create_admins_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('aO8eU3Oz1nJuJVIx7IsnbFMC5m8Hzuujhr4i80n8',1,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6.1 Safari/605.1.15','YToxMDp7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo2OiJfdG9rZW4iO3M6NDA6IkZtUjU1MWNjNG1ybTcza2xFcXozNmx3dXdKcGtoY1hROENTRHJOTTciO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjI3OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvdGFza3MiO3M6NToicm91dGUiO3M6MTE6InRhc2tzLmluZGV4Ijt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjg6ImFkbWluX2lkIjtpOjE7czo0OiJuYW1lIjtzOjY6IkhPRCBJVCI7czoxMjoic2VjdXJpdHlfa2V5IjtzOjE5OiJyZXdzZ2ZAJV4mKm5tZ2hqamtoIjtzOjk6InVzZXJfcm9sZSI7aToxO3M6MTM6InRlbXBfcGFzc3dvcmQiO047czoxMjoidXNlcl9kZXB0X2lkIjtpOjI7fQ==',1765474997),('C2HLYXI9vvDiG7lIXfzTy437vCqkf2QO5YJayrc0',NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6.1 Safari/605.1.15','YTozOntzOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjY6Il90b2tlbiI7czo0MDoiZ29IVzFFYVlRMGM1dVF0TDlnb3RZbEMzOFZ0R01LdEpSY3oycDRBVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMSI7czo1OiJyb3V0ZSI7czo3OiJsYW5kaW5nIjt9fQ==',1765445648),('I0PlZv03Opf3Hx8QsC9Th1QunqDtd9ey2Vj5Mekm',NULL,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6.1 Safari/605.1.15','YTozOntzOjY6Il90b2tlbiI7czo0MDoianlHVkxZODcxRndqYVY5d2JOSURIUGgzT2hFdGFEZ3M2eGlGZzZ0dSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1765776757),('vhpLHun4ofwv1eAtutvaY66db7ajsi0EOxkwbSw9',62,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6.1 Safari/605.1.15','YToxMDp7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo2OiJfdG9rZW4iO3M6NDA6IlZUSGRHOVNVZDZTTUw3Y1lnNnBrZGJFWEQyMDZuaHFEUDNXU0Y3Q2wiO3M6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM1OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYWRtaW4vcmVwb3J0cyI7czo1OiJyb3V0ZSI7czoxOToiYWRtaW4ucmVwb3J0cy5pbmRleCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjYyO3M6ODoiYWRtaW5faWQiO2k6NjI7czo0OiJuYW1lIjtzOjE0OiJTaG9haWIgRmFyb29rYSI7czoxMjoic2VjdXJpdHlfa2V5IjtzOjE5OiJyZXdzZ2ZAJV4mKm5tZ2hqamtoIjtzOjk6InVzZXJfcm9sZSI7aToyO3M6MTM6InRlbXBfcGFzc3dvcmQiO047czoxMjoidXNlcl9kZXB0X2lkIjtpOjE7fQ==',1765450325);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `task_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_info` (
  `task_id` int(50) NOT NULL AUTO_INCREMENT,
  `t_title` varchar(120) NOT NULL,
  `dept_id` int(11) DEFAULT NULL,
  `t_description` text DEFAULT NULL,
  `t_start_time` varchar(100) DEFAULT NULL,
  `t_end_time` varchar(100) DEFAULT NULL,
  `t_user_id` int(20) NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0 = incomplete, 1 = In progress, 2 = complete',
  PRIMARY KEY (`task_id`),
  KEY `task_dept_fk` (`dept_id`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `task_info` WRITE;
/*!40000 ALTER TABLE `task_info` DISABLE KEYS */;
INSERT INTO `task_info` VALUES (76,'Internet/Wifi',2,'bbb','2025-11-17 16:39','2025-11-17 16:39',35,1,2),(65,'ISP PTCL',2,'make network','2025-11-17 14:00','2025-11-17 15:00',30,1,2),(66,'UAN Support',2,'Get UAN support','2025-11-17 12:00','2025-11-17 10:00',30,1,2),(67,'Leave Form Submit',1,'Accept the leaves','2025-11-17 12:00','2025-11-17 14:00',40,1,2),(68,'Treasury Management',3,'eee','2025-11-17 12:00','2025-11-17 12:00',47,1,2),(60,'Leave Form Submit',1,'Submit your leave form','2025-11-13 13:00','2025-11-13 15:00',40,1,2),(61,'Leave Form Submit',1,'d','2025-11-13 12:00','2025-11-13 12:00',40,1,2),(70,'Collections & Customer Service',4,'io','2025-11-17 15:35','2025-11-17 16:30',46,1,2),(71,'Printer',2,'c','2025-11-17 14:54','2025-11-17 17:54',33,1,2),(72,'Compliance & Safety',1,'Do this','2025-11-17 15:01','2025-11-17 15:01',40,1,2),(75,'Projector',2,'rrrr','2025-11-17 16:21','2025-11-17 16:21',35,1,2),(74,'CCTV',2,'bbbb','2025-11-17 16:21','2025-11-17 16:21',35,1,2),(48,'Internet/Wifi',2,'Fix Wifi Issue','2025-11-12 13:00','2025-11-12 16:00',36,1,2),(94,'check cctv',2,'check cctv','2025-12-11 22:41:00','2025-12-11 22:50:00',30,1,2),(59,'ISP NAYATEL',2,'Network Connection issue','2025-11-13 13:00','2025-11-13 17:00',31,1,2),(58,'Internet/Wifi',2,'Solve it','2025-11-13 17:00','2025-11-13 18:25',31,1,2),(57,'CCTV',2,'Solve the issue','2025-11-13 15:00','2025-11-13 18:00',31,1,1),(53,'Internet/Wifi',2,'d','2025-11-12 14:00','2025-11-12 20:00',33,33,2),(77,'Financial Planning & Analysis',3,'bbbb','2025-11-17 16:40','2025-11-17 16:40',47,1,2),(79,'CCTV',2,'p','2025-11-17 06:01','2025-11-17 06:11',34,33,2),(80,'Financial Planning & Analysis',3,'c','2025-11-17 06:01','2025-11-17 06:01',47,33,2),(81,'Tenant Coordination',5,'p','2025-11-17 06:11','2025-11-17 06:11',47,33,2),(82,'ISP NAYATEL',2,'completed','2025-11-17 06:12','2025-11-17 08:12',33,33,2),(84,'SMD',2,'check camera','2025-11-18 02:50','2025-11-18 02:50',30,47,1),(92,'Check',4,'ccccc','2025-12-11 14:37:00','2025-12-11 14:37:00',46,30,0),(93,'task',4,'add','2025-12-11 14:38:00','2025-12-11 14:38:00',46,30,0),(87,'TESTING 00',3,'TEST44','2025-12-09 17:19:00','2025-12-09 17:19:00',47,1,0),(91,'bb',2,'bbbb','2025-12-11 14:25:00','2025-12-11 14:25:00',31,30,0);
/*!40000 ALTER TABLE `task_info` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `task_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `dept_id_fk` (`dept_id`),
  CONSTRAINT `dept_id_fk` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `task_types` WRITE;
/*!40000 ALTER TABLE `task_types` DISABLE KEYS */;
INSERT INTO `task_types` VALUES (1,2,'Software Support'),(2,2,'System Backup'),(3,2,'Internet/Wifi'),(4,2,'Network Support'),(5,2,'UAN Support'),(6,2,'ISP PTCL'),(7,2,'ISP NAYATEL'),(8,2,'ISP Transworld'),(9,2,'GPON Support'),(10,2,'CCTV'),(11,2,'Printer'),(12,2,'SMD'),(13,2,'Projector'),(14,2,'PA System'),(15,1,'Leave Form Submit'),(16,5,'Document Management & Compliance'),(17,5,'Office and Team Support'),(18,5,'Financial Administration'),(19,5,'Listing Management'),(20,5,'Tenant Coordination'),(21,4,'Invoice Generation & Data Management'),(22,4,'Payment Processing & Accounts Reciveable'),(23,4,'Collections & Customer Service'),(24,4,'Reporting & Compliance'),(25,3,'Accounting'),(27,3,'Financial Planning & Analysis'),(29,3,'Treasury Management'),(30,5,'Tax & Compliance'),(31,1,'Recruitment'),(32,1,'Compensation & Benefits'),(33,1,'Training & Development'),(34,1,'Employee Relations & Culture'),(35,1,'Compliance & Safety '),(36,1,'Employee Offboarding');
/*!40000 ALTER TABLE `task_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tbl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(120) NOT NULL,
  `username` varchar(100) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `temp_password` varchar(100) DEFAULT NULL,
  `user_role` int(10) NOT NULL,
  `dept_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `admin_dept_fk` (`dept_id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` VALUES (1,'HOD IT','Admin1','','25f9e794323b453885f5181f1b624d0b',NULL,1,2),(27,'Muhammad Ali Somroo [Manager IT]','IT-1171','03335144719','0bb79d24e223c84304af4d9744c3c5df','',2,2),(28,'Sohail Qaiser [Senior IT Support Officer]','IT-1083','03315515747','0bb79d24e223c84304af4d9744c3c5df','',2,2),(29,'Sarfraz Khan [IT Supervisor]','IT-98','03339154118','0bb79d24e223c84304af4d9744c3c5df','',2,2),(30,'Muhammad Ali Hamza [IT Support Officer]','IT-1163','03001009404','e10adc3949ba59abbe56e057f20f883e','',2,2),(31,'Rehan Tariq [IT Technician]','IT-1150','03118224353','0bb79d24e223c84304af4d9744c3c5df','',2,2),(32,'Ehtisham Masood [IT Technician]','IT-1144','03329870204','0bb79d24e223c84304af4d9744c3c5df','',2,2),(33,'Junaid Fayyaz [IT Technician]','IT-134','03425364204','0bb79d24e223c84304af4d9744c3c5df','',2,2),(34,'Noman Farooq [IT Technician]','IT-1112','03481051566','0bb79d24e223c84304af4d9744c3c5df','',2,2),(35,'Muhammad Iqbal [IT Technician]','IT-1105','03408860099','0bb79d24e223c84304af4d9744c3c5df','',2,2),(36,'Kamran Khalid [IT Technician]','IT-1067','03400691593','e10adc3949ba59abbe56e057f20f883e','',2,2),(20,'Shoaib Khan [IT Inernee]','IT-1000','03174825823','e10adc3949ba59abbe56e057f20f883e','',2,2),(37,'HOD Finance','F-Admin','admin@gmail.com','e10adc3949ba59abbe56e057f20f883e',NULL,1,3),(40,'[IT Technician]','IT-1067','03400691593','0bb79d24e223c84304af4d9744c3c5df','',2,1),(46,'khan','khan','11111111','e10adc3949ba59abbe56e057f20f883e',NULL,2,4),(61,'testHR','testhr','123456789','e10adc3949ba59abbe56e057f20f883e',NULL,2,1),(43,'sk','sk-47','03174825823','e10adc3949ba59abbe56e057f20f883e',NULL,2,1),(47,'khan','khan00','3434343','e10adc3949ba59abbe56e057f20f883e',NULL,2,3),(51,'Anosh','anosh1','Anosh-123@test.com','25d55ad283aa400af464c76d713c07ad',NULL,2,5),(53,'HOD_Billing','billing_HOD1','123456789','e10adc3949ba59abbe56e057f20f883e',NULL,1,4),(54,'HOD-HR','HR_Admin','HR@gmail.com','e10adc3949ba59abbe56e057f20f883e',NULL,1,1),(55,'HODtest','hodtest','','e10adc3949ba59abbe56e057f20f883e',NULL,1,6),(57,'test66','test666','','e10adc3949ba59abbe56e057f20f883e',NULL,2,6),(58,'test90','test90','','e10adc3949ba59abbe56e057f20f883e',NULL,2,6),(62,'Shoaib Farooka','shoaibfiance','12345678','25d55ad283aa400af464c76d713c07ad',NULL,2,1);
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

